package com.zen.utils;

/**
 * @author sreekanth chimbili
 * 
 */

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

import org.apache.log4j.Logger;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;

import cybervillains.ca.ThumbprintUtil;

public class DataUtil {
	public static Fillo fillo;
	public static Connection connection;
	public static Recordset recordset;
	private static Logger logger = Logger.getLogger(DataUtil.class);
	
	public static Object[][] getData(String testCase,String path) throws Exception{
		long l_start = System.currentTimeMillis();
		logger.info("Getting the Data from the Excel sheet and storing into Object Array");
		TestUtil.setExcelFile(path, testCase);
		Object testData[][]=new Object[TestUtil.getRowCount(testCase)-1][1];
		Hashtable<String,String> table=null;
		int index=0;
		logger.info("No,Of Rows are "+TestUtil.getRowCount(testCase));
		for(int rowNum=1;rowNum<TestUtil.getRowCount(testCase);rowNum++){
			table=new Hashtable<String,String>();
			for(int colNum=0;colNum<TestUtil.getColumnCount(testCase);colNum++){
				String key=TestUtil.getCellData(1,colNum,testCase);
				String value=TestUtil.getCellData(rowNum+1, colNum, testCase);
				//System.out.println("Key is "+key+ " and Value is "+value);
				table.put(key, value);
				testData[index][0]=table;
			}
			index++;
		}
		long l_end = System.currentTimeMillis();
		logger.info("Instrumentation :<DataUtil.java>:<getData>: "+ (l_end - l_start));
		return testData;
	}
	
	public static Object[][] getData(Xls_Reader xls, String testCaseName){
		String sheetName=Constants.TESTDATA_SHEET;
		// reads data for only testCaseName
		
		int testStartRowNum=1;
		System.out.println(xls.getCellData(sheetName, 0, testStartRowNum)); 
		while(!xls.getCellData(sheetName, 0, testStartRowNum).equals(testCaseName)){
			testStartRowNum++;
		}
		//System.out.println("Test starts from row - "+ testStartRowNum);
		int colStartRowNum=testStartRowNum+1;
		int dataStartRowNum=testStartRowNum+2;
		
		// calculate rows of data
		int rows=0;
		while(!xls.getCellData(sheetName, 0, dataStartRowNum+rows).equals("")){
			rows++;
		}
		//System.out.println("Total rows are  - "+rows );
		
		//calculate total cols
		int cols=0;
		while(!xls.getCellData(sheetName, cols, colStartRowNum).equals("")){
			cols++;
		}
		//System.out.println("Total cols are  - "+cols );
		Object[][] data = new Object[rows][1];
		//read the data
		int dataRow=0;
		Hashtable<String,String> table=null;
		for(int rNum=dataStartRowNum;rNum<dataStartRowNum+rows;rNum++){
			table = new Hashtable<String,String>();
			for(int cNum=0;cNum<cols;cNum++){
				String key=xls.getCellData(sheetName,cNum,colStartRowNum);
				String value= xls.getCellData(sheetName, cNum, rNum);
				table.put(key, value);
				// 0,0 0,1 0,2
				//1,0 1,1
			}
			data[dataRow][0] =table;
			dataRow++;
		}
		return data;
	}
	
	
	public static void setData(String FILE_PATH,String testCase,String columnName,int rowNo,String result) throws Exception{
		long l_start = System.currentTimeMillis();
		logger.info("Printing the Result to Excel Sheet");
		TestUtil.setExcelFile(FILE_PATH, testCase);
		List<String> colNames=new ArrayList<String>();
		for(int colNo=0;colNo<TestUtil.getColumnCount(testCase);colNo++){
			String value=TestUtil.getCellData(1,colNo,testCase);
			colNames.add(value);
		}
		int colNo=0;
		if(colNames.contains(columnName))
			colNo=colNames.indexOf(columnName);
		TestUtil.setCellData(FILE_PATH,result,rowNo,colNo);
		long l_end = System.currentTimeMillis();
		logger.info("Instrumentation :<DataUtil.java>:<setData>: "+ (l_end - l_start));
	}
	//Logic to Skip the TestCase - Product
	public static boolean isSkip(String testName, String TestCase_Xls_Path) throws Exception{
		long l_start = System.currentTimeMillis();
		logger.info("Checking to Skip the Testcase/Data");
		TestUtil.setExcelFile(TestCase_Xls_Path,Constants.Suite_Xls_SheetName);
		for (int rowNum = 2; rowNum <=TestUtil.getRowCount(Constants.Suite_Xls_SheetName); rowNum++)
		{
			if(testName.equals(TestUtil.getCellData(Constants.Suite_Xls_SheetName,Constants.Suite_Xls_TestCaseId,rowNum))){
				if(TestUtil.getCellData(Constants.Suite_Xls_SheetName,Constants.Runmode,rowNum).equals(Constants.Runmode_YES))
					return true;
				else
					return false;
			}
		}	
		long l_end = System.currentTimeMillis();
		logger.info("Instrumentation :<DataUtil.java>:<isSkip>: "+ (l_end - l_start));
		return false;
	}
	
	public static String getStringInt(String num){
		  try {
			Double num1=Double.valueOf(num);
			int intnum=num1.intValue();
			return new Integer(intnum).toString();
		} catch (Exception e) {
			return num;
		}
		  
	  }
	
	public static List<HashMap<String, String>> read(String path, String query) throws FilloException {
		fillo = new Fillo();
		connection = fillo.getConnection(path);
		recordset = connection.executeQuery(query);
		ArrayList<String> dataColl = recordset.getFieldNames();
		List<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
		while (recordset.next()) {		
			HashMap<String,String> map = new HashMap<String,String>();
			for (String str : dataColl) {
				map.put(str, recordset.getField(str));
			}	
			list.add(map);		
		}
		recordset.close();
		connection.close();
		return list;
	}
	//dup
	public static Object[][] getDataDup(String path, String query) throws Exception{
		fillo = new Fillo();
		connection = fillo.getConnection(path);
		recordset = connection.executeQuery(query);		
		Object testData[][]= new Object[recordset.getCount()][1];
		Hashtable<String,String> table=null;
		int index=0;
		ArrayList<String> dataColl = recordset.getFieldNames();
		while (recordset.next()) {
			table=new Hashtable<String,String>();
			for (String str : dataColl) {
				//System.out.println("kay:--"+str);
				table.put(str, recordset.getField(str));
				//System.out.println("Value:--"+recordset.getField(str));
			}
			testData[index][0]=table;
			index++;
		}
		recordset.close();
		connection.close();
		return testData;
	}
	// Set Test Status - PASS/FAIL/SKIP/IN-COMPLETE
	public static void setDataDup(String path, String uQuery) throws Exception{
		fillo = new Fillo();
		connection = fillo.getConnection(path);
		connection.executeUpdate(uQuery);
		connection.close();
	}
	
	//Logic to Skip the TestCase - Product
		public static boolean Skip(String path, String query, String className) throws Exception{
			fillo = new Fillo();
			connection = fillo.getConnection(path);
			recordset = connection.executeQuery(query);	
			boolean isClassExist = false;			
			while (recordset.next()) {
				if (recordset.getField("TCID").equals(className)) {
					isClassExist = true;
					if (recordset.getField(Constants.Runmode).equals(Constants.Runmode_YES))
						return true;
					else
						return false;
				}
			}
			if (!isClassExist) {
				throw new Exception("Test Case not found in TestCases sheet, please add");
			}
			return false;
		}		
		/*//Logic to Skip the TestCase - Product
		public static boolean Skip1(String path, String query, String className)
				throws Exception {
			List<HashMap<String, String>> data = read(path, query);
			boolean isClassExist = false;
			System.out.println("data" + data);
			for (HashMap<String, String> str : data) {
				if (str.get("TCID").equals(className)) {
					isClassExist = true;
					if (str.get(Constants.Runmode).equals(Constants.Runmode_YES))
						return true;
					else
						return false;
				}
			}
			if (!isClassExist) {
				throw new Exception("Test Case not found in TestCases sheet, please add");
			}
			return false;
		}*/
				
}
