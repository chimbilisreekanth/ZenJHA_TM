package com.zen.utils;

/**
 * @author sreekanth chimbili
 * 
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Hashtable;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestMain {

	public static void main(String[] args) throws IOException {
		//test();
		
		
		String filePath = "C:\\Users\\schimbali\\Desktop";
		String fileName ="DataReqed.xlsx";
		String sheetName = "TestData";
		
        File file =    new File(filePath+"\\"+fileName);
        FileInputStream inputStream = new FileInputStream(file);

        Workbook workbook = null;
        String fileExtensionName = fileName.substring(fileName.indexOf("."));

        if(fileExtensionName.equals(".xlsx")){
        	workbook = new XSSFWorkbook(inputStream);
        }else if(fileExtensionName.equals(".xls")){
        	workbook = new HSSFWorkbook(inputStream);
        }


        Sheet sheet = workbook.getSheet(sheetName);

        int rowCount = sheet.getLastRowNum()-sheet.getFirstRowNum();
        
        System.out.println("rowCount: "+rowCount);

        Row row = sheet.getRow(0);

        Row newRow = sheet.createRow(rowCount+1);

	    for(int j = 0; j < row.getLastCellNum(); j++){
	        Cell cell = newRow.createCell(j);
	        cell.setCellValue("Hello");
	    }

	   try(FileOutputStream outputStream = new FileOutputStream(file)){
		   workbook.write(outputStream);
	   }
	    
	}
	
	public static void test() throws FileNotFoundException, IOException{
		 	/*XSSFWorkbook workbook = new XSSFWorkbook();
	        XSSFSheet sheet = workbook.createSheet("Java Books");
	         
	        Object[][] bookData = {
	                {"Head First Java", "Kathy Serria", 79},
	                {"Effective Java", "Joshua Bloch", 36},
	                {"Clean Code", "Robert martin", 42},
	                {"Thinking in Java", "Bruce Eckel", 35},
	        };
	        
	        Hashtable<String, String> data = new Hashtable<>();
	        data.put("browser", "");
	 
	        int rowCount = 0;
	         
	        for (Object[] aBook : bookData) {
	            Row row = sheet.createRow(++rowCount);
	             
	            int columnCount = 0;
	             
	            for (Object field : aBook) {
	                Cell cell = row.createCell(++columnCount);
	                if (field instanceof String) {
	                    cell.setCellValue((String) field);
	                } else if (field instanceof Integer) {
	                    cell.setCellValue((Integer) field);
	                }
	            }
	             
	        }
	         
	         
	        try (FileOutputStream outputStream = new FileOutputStream("JavaBooks.xlsx")) {
	            workbook.write(outputStream);
	        }
	        System.out.println("end of the code");*/
	}

}
