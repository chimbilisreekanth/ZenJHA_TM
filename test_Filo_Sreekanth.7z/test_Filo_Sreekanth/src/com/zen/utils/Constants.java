package com.zen.utils;

/**
 * @author sreekanth chimbili
 * 
 */
public class Constants {
	
	//Paths
	public static final String chromedriver =  System.getProperty("user.dir")+"\\drivers\\chromedriver.exe";
	public static final String iedriver =  System.getProperty("user.dir")+"\\drivers\\IEDriverServer.exe";
	public static final String REPORTS_PATH = System.getProperty("user.dir")+"\\test_results\\";
	public static final String BACKUP_REPORTS_PATH = System.getProperty("user.dir")+"\\backup_test_results\\";
	
	
	//public static String DataSheetName="Data";
	public static String DataSkipMessage="Test Data has been skipped due to Runmode Set to 'NO'";
	//public static String DataDependsSkipMessage="Test Data has been skipped due to PrimaryDetails Record is not Created";
	public static String TestCaseSkipMessage="Testcase has been Skipped due to Runmode Set to 'NO'";
	public static String Runmode="Runmode";
	public static String Suite_Xls_SheetName="TestCases";
	public static String Suite_Xls_TestCaseId="TCID";
	public static String Runmode_YES="Y";
	public static String Runmode_NO="N";
	public static final long globalWait = 250;
	public static final Object RUNMODE_COL = "Runmode";
	
	public static final String RESULT = "Result";
	public static final String ID = "id";
	public static final String KEYWORD_PASS = "PASS";
	public static final String KEYWORD_FAIL = "FAIL";
	public static final String KEYWORD_INCOMPLETE = "IN-COMPLETE";
	public static final String KEYWORD_SKIP = "SKIPPED";
	
	//Data-Core
	public static String FILE_PATH = System.getProperty("user.dir")+"\\data\\TestData.xlsx";
	public static String TestCase_Xls_Path=System.getProperty("user.dir")+"\\data\\TestCase.xlsx";
	public static final String TESTDATA_SHEET = "TestData";
	public static final String TESTCASES_SHEET = "TestCases";
	public static final String CORE_PROPERTIES_FILE_PATH = System.getProperty("user.dir")+"\\testConfig\\Config_CORE.properties";
	
	//Data-bnc
	public static String bnc_FILE_PATH = System.getProperty("user.dir")+"\\data\\bnc_TestData.xlsx";
	public static String bnc_TestCase_Xls_Path=System.getProperty("user.dir")+"\\data\\bnc_TestCase.xlsx";
	//public static final String bnc_TESTDATA_SHEET = "bnc_TestData";
	//public static final String bnc_TESTCASES_SHEET = "bnc_TestCases";
	public static final String BNC_PROPERTIES_FILE_PATH = System.getProperty("user.dir")+"\\testConfig\\Config_BNC.properties";
	public static final String testReportName= "HWB_Regression_Cycle1";
	//
}
