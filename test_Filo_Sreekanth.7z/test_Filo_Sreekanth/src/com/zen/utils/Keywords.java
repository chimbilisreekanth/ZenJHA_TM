package com.zen.utils;

/**
 * @author sreekanth chimbili
 * 
 */

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.Test;

import com.codoid.products.exception.FilloException;
import com.codoid.products.fillo.Connection;
import com.codoid.products.fillo.Fillo;
import com.codoid.products.fillo.Recordset;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.bnc.pages.AllPages;

public class Keywords {
	
	public WebDriver driver;
	public ExtentReports extent = ExtentManager.getInstance();
	public ExtentTest test;
	public WebDriverWait wait;
	public static Properties properties;
	public AllPages pages;

	/*public WebDriverWait wait;	
	public ExtentTest test;
	public WebDriver driver;*/
	public String globalwait = "1500";
		
	public Keywords (WebDriver driver, ExtentTest test){
		this.driver = driver;
		this.test = test;
		//menu = PageFactory.initElements(driver, TopMenu.class);
	}
	
	@FindBy(xpath="//h1[@id='WLdialogTitle']")
	public WebElement err_popup;
	
	@FindBy(xpath="//button[contains(.,'OK')]")
	public WebElement err_Ok_button;
	
	@FindBy(xpath="//p/p")
	public WebElement err_text;
	
	@FindBy(xpath="//label")
	public List<WebElement> labelvalidation_otherthanLinks;
	
	@FindBy(xpath="//a/span[@class='ng-scope']")
	public List<WebElement> labelvalidation_links;
	
	public void handle_weAreSorry(){
		if(isElementVisibile(err_popup)){
			isElementClickable(err_Ok_button);
			test.log(LogStatus.INFO, "Text dislayed on 'weAreSorry' popup:- "+getText(err_text));
			clickOnElement(err_Ok_button);
		}
	}
	
	/*public TopMenu getMenu() {
		return menu;		
	}*/
	public void takeScreenShot(){
		Date d=new Date();
		String screenshotFile=d.toString().replace(":", "_").replace(" ", "_")+".png";
		String filePath=Constants.REPORTS_PATH+"screenshots//"+screenshotFile;
		// store screenshot in that file
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		test.log(LogStatus.INFO,test.addScreenCapture(filePath));
	}
	
	
		
	public boolean isElementsVisibile(List<WebElement> element)
	{
		boolean bExists=false;
		try{
			wait = new WebDriverWait(this.driver,60);   
			wait.until(ExpectedConditions.visibilityOf((WebElement) element));
			bExists=true;
			//return true;
		}
		catch (Exception e){
		}
		return bExists;
	}

	public boolean isElementClickable(WebElement element)
	{
		boolean bExists=false;
		try{
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            wait = new WebDriverWait(this.driver, Constants.globalWait);
            wait.until(ExpectedConditions.elementToBeClickable(element));
			return true;
		}
		catch (Exception e){
		}
		return bExists;
	}
	// for verify page load
	public boolean verifyPageLoad(WebElement element){
		if(element.isDisplayed()){
			return true;
		}
		return false;
	}
	// for drop-down value selection - using index
	public void selectDropDownValue(WebElement element, int index) throws InterruptedException{
		isElementClickable(element);
		//Thread.sleep(5000);
		Select dropdown = new Select(element);
		dropdown.selectByIndex(index);
		//dropdown.selectByVisibleText(value);
		test.log(LogStatus.INFO, "Clicked on DropDown:- "+element.getAttribute("name")+" -- selected DropDownValue - "+index);
	}
	// for drop-down value selection - using visible text
	public void selectDropDownValue(WebElement element, String text){
		isElementVisibile(element);
		Select dropdown = new Select(element);
		dropdown.selectByVisibleText(text);
		//dropdown.selectByVisibleText(value);
		test.log(LogStatus.INFO, "Clicked on DropDown:- "+element.getAttribute("name")+" -- selected DropDownValue - "+text);
	}
	// for entering data on text-boxes
	public void EnterDataOnTextBox(WebElement element, String value){
		isElementVisibile(element);
		element.clear();
		element.sendKeys(value);
		test.log(LogStatus.INFO, "Text entered on:- "+element.getAttribute("data-ng-model")  +" -- Value is - "+value);
	}
	// for clicking buttons
	public void ClickOn(WebElement element) throws InterruptedException{
		isElementClickable(element);
		test.log(LogStatus.INFO, "Clicked on Button:- "+element.getText());
		element.click();		
	}
	// for check-boxes, radio-buttons.
	public void ClickOnCheckbox(WebElement element) throws InterruptedException{
		element.click();
		test.log(LogStatus.INFO, "Clicked On Checkbox:- "+element.getAttribute("id"));
	}
	// for clicking icons
	public void ClickOnIcon(WebElement element) throws InterruptedException{
		isElementVisibile(element);
		element.click();
		test.log(LogStatus.INFO, "Clicked on Icon:- "+element.getAttribute("data-ng-click"));
	}
	
	// to verify the text on page/next page.	
	public  void verifyTitle_Content(WebElement element, String content) throws InterruptedException{
		//Thread.sleep(2000);
		String actualTitle= element.getText();
		String expectedTitle=content.trim();		
		//Assert.assertEquals(actualTitle.contains(content), expectedTitle,"Content/Title is not Equal");
		//test.log(LogStatus.INFO, "Page loaded successfully:- "+content);		
		Assert.assertTrue(actualTitle.contains(content), "Content/Title is not Equal");
		test.log(LogStatus.INFO, "Page loaded successfully:- "+content);
	}
	
	/*public  void ScrollDown(){
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("scroll(0, 250)");
	}
	public  void ScrollUp(){
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("scroll(250, 0)");
	}*/
	
	/*public void clickElement(WebElement element){
		isElementClickable(element);
		WebElement elemnt = (element);
		Actions action = new Actions(driver);
		action.moveToElement(elemnt).click().perform();
	}*/
	
	public void clickOnElement(WebElement element) {
		try {
			isElementClickable(element);			
			Actions action = new Actions(driver);
			action.click(element).perform();
		} catch (StaleElementReferenceException e) {
			System.out.println("Element is not attached to the page document "
					+ e.getStackTrace());
		} catch (NoSuchElementException e) {
			System.out.println("Element " + element + " was not found in DOM "
					+ e.getStackTrace());
		} catch (Exception e) {
			System.out.println("Element " + element + " was not clickable "
					+ e.getStackTrace());
		}
	}
	// to move scroll to element up/down.
	public void moveScrollToWebElement(WebElement element) throws InterruptedException {		
		WebElement elment = element;
		Thread.sleep(2000);
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", elment);
		Thread.sleep(2000);
	}
	
	public boolean isPopupPresent(WebElement element) {
		if (element.isDisplayed()) {
			return true;
		} else {
			return false;
		}
	}
			
	public void WaitForPage(Keywords page) throws InterruptedException, IOException{
		boolean bExists=false;

		for(int i=0; i<=100;i++) {
			bExists = page.Exists();
			if (bExists==true){
				Thread.sleep(2000);
				break;
			}else
			Thread.sleep(2000);
		}
		if (bExists==false)
		{
			test.log(LogStatus.FAIL,"navigation from "+this.getClass().getName()+" to "+ page.getClass().getName() + " is Failed");
		}
		else{
			test.log(LogStatus.INFO,"navigation from "+this.getClass().getName()+" to "+ page.getClass().getName() + " is Pass");
		}

	}
	public boolean Exists(WebElement element) {
           boolean bExists=false;
           try{
                  WebDriverWait wait = new WebDriverWait(this.driver, Constants.globalWait);
                  wait.until(ExpectedConditions.visibilityOf(element)); 
                  test.log(LogStatus.INFO, "element Exists:-"+element.getText());
                  return true;
           }
           catch (Exception e){
           }
         return bExists;
    }    
    public void WaitForPage(Keywords page, WebElement element) throws InterruptedException, IOException{
           boolean bExists=false;
           for(int i=0; i<=10;i++)
           {
                  bExists = page.Exists(element);                
                  if (bExists==true){
                       Thread.sleep(2000);
                        break;
                  }                        
                  else
                  Thread.sleep(1000);
           }
           if (bExists==false){
        	   test.log(LogStatus.FAIL,"navigation from "+this.getClass().getName()+" to "+ page.getClass().getName() + " is Failed");
           }else{
        	   test.log(LogStatus.INFO,"navigation from "+this.getClass().getName()+" to "+ page.getClass().getName() + " is Pass");
           }

    }
    public boolean Exists() throws IOException {
		return false;
	}    
    
    // for check-box
    public void selectCheckbox(List<WebElement> element, String text) throws InterruptedException{
    	List<WebElement> checkboxs = element;	
    		for(WebElement checkboxsList : checkboxs){
    			if(checkboxsList.getText().equalsIgnoreCase(text)){ 
    				moveScrollToWebElement(checkboxsList); 
    				checkboxsList.click();
    				test.log(LogStatus.INFO, "Selcted Checkbox:-"+text);
                    break;
    			}
    		}		
    	}
    // for List, 
   /* public void selectOption(List<WebElement> element, String text) throws InterruptedException{
    	List<WebElement> elements = element;	
    		for(WebElement elementsList : elements){
    			if(elementsList.getText().equalsIgnoreCase(text)){ 
    				moveScrollToWebElement(elementsList); 
    				//clickOnElement(elementsList);
    				elementsList.click();
    				test.log(LogStatus.INFO, "Selcted option:--"+text);
                    break;
    			}
    		}		
    	}*/
    
    public void selectOption(List<WebElement> element, String text) throws InterruptedException{
    	List<WebElement> elements = element;	
    		for(WebElement elementsList : elements){
    			/*String elementText = elementsList.getText();
    			System.out.println(elementText);*/
    			if(elementsList.getText().contains(text)){
    				//moveScrollToWebElement(elementsList);
    				clickOnElement(elementsList);
    				test.log(LogStatus.INFO, "Selcted option:-"+text);
                    break;
    			}
    		}		
    	}
    
    
    // date picker if 2months are displays after selecting date picker icon
	public void datePicker_2Months(String date) {
		// String date = "25-May 2016";
		// select Month&Year
		String spliter[] = date.split("-");
		String monthYear = spliter[1];
		String day = spliter[0];
		// Month navigation clicks
		List<WebElement> monthYearList = driver.findElements(By.xpath("//div[@class='uib-daypicker ng-scope']/table/thead/tr/th[@colspan='5']/button/strong"));

		for (int i = 0; i < monthYearList.size(); i++) {
			// System.out.println(monthYearList.get(i).getText());
			// selecting the MonthYear
			if (monthYearList.get(i).getText().equalsIgnoreCase(monthYear)) {
				// selecting the date
				List<WebElement> dayList = driver.findElements(By.xpath("//div[@class='uib-daypicker ng-scope']["+ i + 1 + "]/table/tbody/tr/td"));
				for (WebElement days : dayList) {
					// System.out.println(days.getText());
					if (days.getText().equalsIgnoreCase(day)) {
						days.click();
						test.log(LogStatus.INFO, "Selcted Date:-"+date);
						return;
					}
				}
			}
		}

	}
	
	public void datePicker(String date) {
		// String date = "25-May 2016";
		// select Month&Year
		String spliter[] = date.split(",");
		String monthYear = spliter[1];
		String day = spliter[0];
		// Month navigation clicks
		WebElement monthYearList = driver.findElement(By.xpath("//div[@class='uib-daypicker ng-scope']/table/thead/tr/th[@colspan='5']/button/strong"));

			if (monthYearList.getText().equalsIgnoreCase(monthYear)) {
				// selecting the date
				List<WebElement> dayList = driver.findElements(By.xpath("//div[@class='uib-daypicker ng-scope']/table/tbody/tr/td"));
				for (WebElement days : dayList) {
					// System.out.println(days.getText());
					if (days.getText().equalsIgnoreCase(day)) {
						days.click();
						test.log(LogStatus.INFO, "Selcted Date:-"+date);
						return;
					}
				}
			}
		}
	
	// date picker if 1month is displays after selecting date picker icon
	public void datePickernew(String date) throws InterruptedException {
		String spliter[] = date.split(",");
		//String year = spliter[2];
		String month = spliter[1];
		String day = spliter[0];
		
		// Month navigation clicks
		WebElement monthYearList = driver.findElement(By.xpath("//button[@role='heading']"));
		monthYearList.click();
		
		List<WebElement> monthList = driver.findElements(By.xpath("//button[@type='button']"));
		for (WebElement months : monthList) {
			if (months.getText().equalsIgnoreCase(month)) {
				months.click();
				Thread.sleep(2000);
			List<WebElement> dayList = driver.findElements(By.xpath("//div[@class='uib-daypicker ng-scope']/table/tbody/tr/td"));
				for (WebElement days : dayList) {
					// System.out.println(days.getText());
					if (days.getText().equalsIgnoreCase(day)) {
						days.click();
						test.log(LogStatus.INFO, "Selcted Date:-"+date);
						return;
					}
				}
			}
		}
	}
		
	public void WaitForElementTextVisible(final WebElement element) throws IOException{
		try {
		WebDriverWait wait = new WebDriverWait(this.driver, 10);
		wait.until(new ExpectedCondition<Boolean>() {
            public Boolean apply(WebDriver d) {
                return element.getText().length()!= 0;
            }
        });
		test.log(LogStatus.INFO,"Wait Completed: element:-"+element.toString()+" is visible");
		Thread.sleep(500);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getTextOfLabel(WebElement element){
		//Get the Text from screen
		String text= element.getAttribute("value");
		test.log(LogStatus.INFO,"Text displayd on Label:-"+element.toString());
		return text;
	}

	public String getText(WebElement element){
		//Get the Text from popups etc
		String text=element.getText();
		test.log(LogStatus.INFO,"Text displayd on WebElement is:-"+text);
		return text;
	}
	
	public String getText_text(WebElement element){
		test.log(LogStatus.INFO,"Getting value from"+element.getAttribute("text"));
		return element.getAttribute("text");
	}
	
	public String getText_value(WebElement element){
		test.log(LogStatus.INFO,"Getting value from"+element.getAttribute("value"));
		return element.getAttribute("value");
	}
	
	public void dragAndDrop(WebElement sourceElement, WebElement destinationElement) throws InterruptedException {
		Thread.sleep(2000);
		Actions builder = new Actions(driver);
		Action dragAndDrop = builder.clickAndHold(sourceElement).moveToElement(destinationElement)
				   			.release(destinationElement).build();
		dragAndDrop.perform();
		test.log(LogStatus.INFO,"Drag and Drop:- from-"+sourceElement.getText()+"To-"+destinationElement.getText());
	}
	
	 public void dragAndDrop1(WebElement sourceElement, WebElement destinationElement){
	    (new Actions(driver)).dragAndDrop(sourceElement, destinationElement).perform();
	    test.log(LogStatus.INFO,"Drag and Drop:- from"+sourceElement.toString()+" To"+destinationElement.toString());
	 }
	 
	 public void rightClick(WebElement element){
		Actions action = new Actions(driver).contextClick(element);
		action.build().perform();
		test.log(LogStatus.INFO,"Performed Right click on:-"+element.toString());
	 }
	 public void escClick(){
		Actions action = new Actions(driver);
	    action.sendKeys(Keys.ESCAPE).build().perform();
	 }
	 public void clearData_Textfield(WebElement element){
		element.clear();
		test.log(LogStatus.INFO,"Cleared data on Textfield:-"+element.getAttribute("data-ng-model"));
	 }
	 
	public void uiVal_ReadOnly(WebElement element) {
		String add = element.getAttribute("readonly");
		if (add == null)
			test.log(LogStatus.INFO, element.getText()
					+ "-- is not a readonly field");
		else if (add.contentEquals("true"))
			test.log(LogStatus.INFO, element.getText()
					+ "-- is a readonly field");
		else
			test.log(LogStatus.INFO, "Field is -" + add);
	}
	 
	 public static String getNextWorkingDayfromCurrentDate() {
			Calendar cal = Calendar.getInstance();
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			cal.add(Calendar.DATE, 1);
	 		if(cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY){
				cal.add(Calendar.DATE, 2);
			}else if(cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY){
				cal.add(Calendar.DATE, 1);
			}
			String date= dateFormat.format(cal.getTime()); 
			return date.toString();
		}
		
		public static String getPrevWorkingDayfromCurrentDate() {
			Calendar cal = Calendar.getInstance();
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			cal.add(Calendar.DATE, -1);
	 		if(cal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY){
				cal.add(Calendar.DATE, -1);
			}else if(cal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY){
				cal.add(Calendar.DATE, -2);
				}
			String date= dateFormat.format(cal.getTime()); 
			return date.toString();
		}
		
		public static String getCustomDatePast(int value,String info) {			
			Calendar cal = Calendar.getInstance();
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			if(info == "M"){
				cal.add(Calendar.MONTH, -value);
			}else if(info == "Y"){
				cal.add(Calendar.YEAR, -value);
			}else if(info == "D"){
				cal.add(Calendar.DATE, -value);
			}	
			String date= dateFormat.format(cal.getTime()); 
			return date.toString();
		}
		
	public static String getCustomDateFuture(int value,String info) {		
			Calendar cal = Calendar.getInstance();
			DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
			if(info == "M"){
				cal.add(Calendar.MONTH, value);
			}else if(info == "Y"){
				cal.add(Calendar.YEAR, value);
			}else if(info == "D"){
				cal.add(Calendar.DATE, value);
			}	
			String date= dateFormat.format(cal.getTime()); 
			return date.toString();
		}
	
	public void uiVal_EnableDisableStatus(WebElement element) {
		if (element.isEnabled()) {
			test.log(LogStatus.INFO,element.getText()+"--Element is Enable");
		} else {
			test.log(LogStatus.INFO,element.getText()+"--Element is Disabled");
		}
	}
	
	public void uiVal_DefaultValue(WebElement element){
		String defaultValue = element.getAttribute("value");
		test.log(LogStatus.INFO,"Default Value of --"+element.getText()+"is"+defaultValue);
		//element.getAttribute("placeholder");
	}
	
	public void uiVal_MaxLength(WebElement element){
		String flength = element.getAttribute("maxlength");
		test.log(LogStatus.INFO,"Max length of --"+element.getText()+"is"+flength);
	}
	
	public static void uiVal_InputValues(WebElement element) {
	    String[] invalidChars = {"#", "!", "$", "@", "%", "^", "&"};
	    String name = "abcdefghijklmnopqrstuvwxyz";    
	    for (String invalid : invalidChars) {
	    	element.clear();
	    	element.sendKeys(name + invalid);
	       /* btn_submit.click();
	        String alertMessage = d.switchTo().alert().getText();
	        System.out.println(invalid);
	        if (alertMessage.equals("First name Should not contain Special Characters")) {
	            System.out.println("Error displayed: First name Should not contain Special Characters");
	            d.switchTo().alert().dismiss();
	        } else {
	            System.out.println("Accepted");
	        }*/
	    }
	}
	
	public void uiVal_labels(String eleType, String txt) {
		if (eleType.equalsIgnoreCase("link")) {
			for (WebElement element : labelvalidation_links) {
				if (element.getText().equalsIgnoreCase(txt)) {
					test.log(LogStatus.PASS,"lable prasented" + txt);
				} else {
					test.log(LogStatus.FAIL,"lable not prasented"+ txt);
				}
			}
		} else {
			for (WebElement element : labelvalidation_otherthanLinks) {
				if (element.getText().equalsIgnoreCase(txt)) {
					test.log(LogStatus.PASS,"lable prasented" + txt);
				} else {
					test.log(LogStatus.FAIL,"lable not prasented"+ txt);
				}
			}
		}
	}
	
	
	//BaseTests
	
	public void invokeBrowser(String bType) throws InterruptedException{
		switch (bType) {
		case "ff":
			driver = new FirefoxDriver();
			test.log(LogStatus.INFO, "Firefox - browser has been opened");
			break;
		case "ch":
			System.setProperty("webdriver.chrome.driver", Constants.chromedriver);
			driver = new ChromeDriver();
			test.log(LogStatus.INFO, "Chrome - browser has been opened");
			break;
		case "ie":
			System.setProperty("webdriver.ie.driver", Constants.iedriver);
			driver = new InternetExplorerDriver();
			test.log(LogStatus.INFO, "InternetExplorer - browser has been opened");
			break;
		default:
			System.out.println("There is no value for Browser, hence invoking Firefox broser");
			driver = new FirefoxDriver();
			test.log(LogStatus.INFO, "Firefox - browser has been opened");
			break;
		}		
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(Constants.globalWait, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(120, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
	}
	
	public boolean isElementVisibile(WebElement element)
	{
		boolean bExists=false;
		try{
			wait = new WebDriverWait(this.driver,60);
			wait.until(ExpectedConditions.visibilityOf(element));
			bExists=true;
		}
		catch (Exception e){
		}
		return bExists;
	}
	
	public Properties loadProperties(String PROPERTIES_FILE_PATH){
		File file = new File(PROPERTIES_FILE_PATH);		  
		FileInputStream fileInput = null;
		Properties prop = null;
		try {
			prop = new Properties();
			fileInput = new FileInputStream(file);
			prop.load(fileInput);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return prop;
	}	
	
	
	
	
	
	 
}
