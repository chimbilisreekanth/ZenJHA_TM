package com.zen.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.bnc.pages.AllPages;
import com.zen.bnc.pages.Loginpage;
import com.zen.bnc.pages.RolePage;
import com.zen.utils.Constants;
import com.zen.utils.DataUtil;
import com.zen.utils.ExtentManager;

public class BaseTests {
	public WebDriver driver;
	public ExtentReports extent = ExtentManager.getInstance();
	public ExtentTest test;
	public WebDriverWait wait;
	public static Properties properties;
	public AllPages pages;
	
	/*public void loginToBNC(ExtentTest test) throws InterruptedException, IOException{
		Properties prop = loadProperties(Constants.BNC_PROPERTIES_FILE_PATH);
		invokeBrowser(prop.getProperty("browser"));
		
		pages = new AllPages(driver, test);
		pages.launchingPage.gotoLoginpage(prop.getProperty("bncURL"));
		pages.launchingPage.WaitForPage(pages.loginpage, pages.loginpage.userName);
		
		Object page = pages.loginpage.doLogin(prop.getProperty("bnc_UserName"),prop.getProperty("bnc_Pwd"));			
		if (page instanceof Loginpage)
			Assert.fail("Login fail -- credentials are incorrect");
		else if (page instanceof RolePage) {
			System.out.println("Login successfull");
		}
		pages.loginpage.WaitForPage(pages.rolePage, pages.rolePage.Continue_Button);
		pages.rolePage.gotoHomepage(prop.getProperty("role"));
		pages.rolePage.WaitForPage(pages.homePage, pages.homePage.CustomerSearch);
		pages.rolePage.takeScreenShot();		
		if (extent != null){
			extent.endTest(test);
			extent.flush();
		}
	}*/
	
	public void invokeBrowser(String bType) throws InterruptedException{
		switch (bType) {
		case "ff":
			driver = new FirefoxDriver();
			test.log(LogStatus.INFO, "Firefox - browser has been opened");
			break;
		case "ch":
			System.setProperty("webdriver.chrome.driver", Constants.chromedriver);
			driver = new ChromeDriver();
			test.log(LogStatus.INFO, "Chrome - browser has been opened");
			break;
		case "ie":
			System.setProperty("webdriver.ie.driver", Constants.iedriver);
			driver = new InternetExplorerDriver();
			test.log(LogStatus.INFO, "InternetExplorer - browser has been opened");
			break;
		default:
			System.out.println("There is no value for Browser, hence invoking Firefox broser");
			driver = new FirefoxDriver();
			test.log(LogStatus.INFO, "Firefox - browser has been opened");
			break;
		}		
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(Constants.globalWait, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(120, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
	}
	
	public void takeScreenShot(){
		Date d=new Date();
		String screenshotFile=d.toString().replace(":", "_").replace(" ", "_")+".png";
		String filePath=Constants.REPORTS_PATH+"screenshots//"+screenshotFile;
		// store screenshot in that file
		File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		
		try {
			FileUtils.copyFile(scrFile, new File(filePath));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		test.log(LogStatus.INFO,test.addScreenCapture(filePath));
	}
	
	public boolean isElementVisibile(WebElement element)
	{
		boolean bExists=false;
		try{
			wait = new WebDriverWait(this.driver,60);
			wait.until(ExpectedConditions.visibilityOf(element));
			bExists=true;
		}
		catch (Exception e){
		}
		return bExists;
	}
	
	public Properties loadProperties(String PROPERTIES_FILE_PATH){
		File file = new File(PROPERTIES_FILE_PATH);		  
		FileInputStream fileInput = null;
		Properties prop = null;
		try {
			prop = new Properties();
			fileInput = new FileInputStream(file);
			prop.load(fileInput);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return prop;
	}
	
	public void UpdateResults(ITestResult testResult, String Scenarioid, String className, int rowNo) throws Exception {
		String uQuery;
		System.out.println("afterTest--"+Scenarioid);
		int result = testResult.getStatus();
		if (result == 3) {
			uQuery = "update "+className+" set Result = '"+Constants.KEYWORD_SKIP+"' where Scenario="+Scenarioid;
			//DataUtil.setData(Constants.bnc_FILE_PATH,className, Constants.RESULT, rowNo,Constants.KEYWORD_SKIP);
			DataUtil.setDataDup(Constants.bnc_FILE_PATH, uQuery);
			System.out.println("Skipped Test Case:--"+className+"-"+rowNo);
			test.log(LogStatus.SKIP, "Skipped due to Runmode Set to 'NO':--"+className+"-"+rowNo);
		} else if (result == 2) {
			uQuery = "update "+className+" set Result = '"+Constants.KEYWORD_INCOMPLETE+"' where Scenario="+Scenarioid;
			//DataUtil.setData(Constants.bnc_FILE_PATH,className, Constants.RESULT, rowNo,Constants.KEYWORD_FAIL + " ");
			DataUtil.setDataDup(Constants.bnc_FILE_PATH, uQuery);
			System.out.println("INCOMPLETE Test Case:--"+className+"-"+rowNo);
			test.log(LogStatus.FAIL,"INCOMPLETE Test Case due to hard Failure:--"+className+"-"+rowNo);
			takeScreenShot();
		} else if (result == 1) {
			uQuery = "update "+className+" set Result = '"+Constants.KEYWORD_PASS+"' where Scenario="+Scenarioid;
			DataUtil.setDataDup(Constants.bnc_FILE_PATH, uQuery);
			//DataUtil.setData(Constants.bnc_FILE_PATH,className, Constants.RESULT, rowNo,Constants.KEYWORD_PASS);
			//DataUtil.setData(Constants.bnc_FILE_PATH,className, Constants.RESULT, rowNo,pages.aO_finalPage.resultStatus());
			System.out.println("Pass Test Case:--"+className+"-"+rowNo);
			//DataUtil.setData(Constants.bnc_FILE_PATH,className, Constants.ID, rowNo, pages.aO_finalPage.result());
			test.log(LogStatus.PASS,"Passed Test Case:--"+className+"-"+rowNo);
			takeScreenShot();
			}		
	}
	
	public void UpdateResults_Validations(String Scenarioid, String className, int rowNo) throws Exception {
		String uQuery = "update "+className+" set Result = '"+Constants.KEYWORD_FAIL+"' where Scenario="+Scenarioid;
		DataUtil.setDataDup(Constants.bnc_FILE_PATH, uQuery);
		System.out.println("Failed due to Validation Failure:--"+className+"-"+rowNo);
		test.log(LogStatus.FAIL, "Failed due to Validation Failure:--"+className+"-"+rowNo);
	}

}