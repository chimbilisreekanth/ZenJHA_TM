package com.zen.core.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.zen.utils.Keywords;

public class AllPages {
	private final  WebDriver driver;
    private final ExtentTest test;
    
	
    //All pages
    public Keywords keywords;
    public AddOpportunity addOpportunity;
    public EditOpportunity editOpportunity;
    public HomePage homePage ;
    public LaunchingPage launchingPage;
    public Loginpage loginpage;
    public Manage_Opportunities manage_Opportunities;
    public Menus menus;
    public OpportunityManagement opportunityManagement;
    public RolePage rolePage;
    
    //All pages Factory
    public AllPages(WebDriver driver, ExtentTest test) {  
        super();  
        this.driver = driver;
        this.test = test;
        PageFactory.initElements(driver, this);
        
        keywords = new Keywords(driver, test);
        addOpportunity = new AddOpportunity(driver, test);
        editOpportunity= new EditOpportunity(driver, test);
        homePage= new HomePage(driver, test);
        launchingPage= new LaunchingPage(driver, test);
        loginpage= new Loginpage(driver, test);
        manage_Opportunities= new Manage_Opportunities(driver, test);
        menus= new Menus(driver, test);
        opportunityManagement= new OpportunityManagement(driver, test);
        rolePage= new RolePage(driver, test);
    }
}
