package com.zen.core.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.zen.utils.Keywords;

public class Manage_Opportunities extends Keywords{
	

	public Manage_Opportunities(WebDriver driver, ExtentTest test) {
		super(driver, test);
	}
	@FindBy(xpath="//span[@class='icon accentColor2'][text()='a']")
	public WebElement Add_icon;
	
	@FindBy(xpath="//input[@name='customerName']")
	public WebElement customerName;
	
	@FindBy(xpath="//input[@name='lastName']")
	public WebElement popup_customerLname;
	
	@FindBy(xpath="//*[@data-ng-click='doPartySearch()']")
	public WebElement popup_Search_button;
	
	@FindBy(xpath="//*[@data-ng-click='doPartySearch()']")
	public WebElement popup_SelectCustomer;
	
	@FindBy(xpath="//*[@data-ng-click='doPartySearch()']")
	public WebElement popup_Continue_button;
	
	@FindBy(xpath="//h1[text()='We�re Sorry...']")
	public WebElement NonProcessingDay_Popup;
	
	@FindBy(xpath="//a[text()='v']")
	public WebElement shoppingCart_popup;
	
	@FindBy(xpath="//span[contains(.,'Opportunity Management')]")
	public WebElement OpportunityManagement_page;
	
	@FindBy(xpath="//span[@data-ng-click='showSearchDialog()']")
	public WebElement OpportunityManagement_search_button;
	
	@FindBy(xpath="//select[@aria-label='View By']")
	public WebElement SearchPopup_ViewBy;
	
	@FindBy(xpath="//select[@aria-label='Date']")
	public WebElement SearchPopup_Date;
	
	@FindBy(xpath="//input[@placeholder='Stage']")
	public WebElement SearchPopup_Stage;
	
	@FindBy(xpath="//input[@placeholder='Status']")
	public WebElement SearchPopup_Status;
	
	
	@FindBy(xpath="//button[@data-ng-click='searchReferrals()']")
	public WebElement SearchPopup_searchReferrals;
	
	@FindBy(xpath="//div[@title='Open']")
	public WebElement Referral;
	
	// Model pop-up - Products
	
	@FindBy(xpath="//h2[@class='modalHeader']")
	public WebElement Procucts_modalHeader;
	
	@FindBy(xpath="//a[@class='icon']")
	public WebElement Procucts_modalHeader_close;
	
	@FindBy(xpath="//a[@class='icon']")
	public WebElement OM_SettingsIcon;

	@FindBy(xpath="//label[@id='selectAll']")
	public WebElement selectAll;
	
	
	public void LoadOMs(String Date, String ViewBy) throws InterruptedException{		
			isElementClickable(OpportunityManagement_search_button);
			moveScrollToWebElement(OpportunityManagement_search_button);
			clickOnElement(OpportunityManagement_search_button);
			isElementClickable(SearchPopup_ViewBy);
			selectDropDownValue(SearchPopup_ViewBy, ViewBy);
			selectDropDownValue(SearchPopup_Date, Date);
			clickOnElement(SearchPopup_Stage);
			clickOnElement(selectAll);
			clickOnElement(SearchPopup_Status);
			clickOnElement(selectAll);
			//Thread.sleep(5000);
			isElementClickable(SearchPopup_searchReferrals);
			clickOnElement(SearchPopup_searchReferrals);
			//isElementDisplayed(OpportunityManagement_page);
		//};
	}
	
	public EditOpportunity EditOM() throws InterruptedException{
		//isElementClickable(OM_SettingsIcon);
		EditOpportunity editOpportunity=null;
		if(isElementVisibile(Referral)){					
			clickOnElement(Referral);
			takeScreenShot();
			
			editOpportunity = new EditOpportunity(driver, test);
			PageFactory.initElements(driver, editOpportunity);			
		}
		return editOpportunity;
	}
	
	public AddOpportunity navigateToAddOpportunity() throws InterruptedException{
		ClickOnAddRefferalsButton();		
		if(isElementVisibile(Procucts_modalHeader)){
			isElementClickable(Procucts_modalHeader_close);
			clickOnElement(Procucts_modalHeader_close);
		}
		AddOpportunity addOpportunity = new AddOpportunity(driver, test);		
		PageFactory.initElements(driver, addOpportunity);
		return addOpportunity;
		
	}
	
	/*public boolean isAddiconDisplayed(){
		return isElementVisibile(Add_icon);
	}*/
			
	public void AddCustomerName() throws InterruptedException{		
		ClickOnIcon(Add_icon);
		ClickOn(customerName);		
		EnterDataOnTextBox(popup_customerLname, "sr");
		ClickOn(popup_Search_button);
		ClickOn(popup_SelectCustomer);
		takeScreenShot();
		ClickOn(popup_Continue_button);		
	}
	
	public void ClickOnAddRefferalsButton() throws InterruptedException{
		moveScrollToWebElement(Add_icon);
		isElementClickable(Add_icon);
		ClickOnIcon(Add_icon);
	}
}
