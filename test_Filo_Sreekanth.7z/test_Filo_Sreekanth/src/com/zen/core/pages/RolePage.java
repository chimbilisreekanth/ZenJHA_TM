package com.zen.core.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class RolePage extends Keywords{

	public RolePage(WebDriver driver, ExtentTest test){
		super(driver, test);
	}

	@FindBy(xpath="//button[@class='primaryActionButton']")
	public WebElement Continue_Button;
	
	@FindBy(xpath="//span[@class='ng-scope'][text()='Customer Search']")
	public WebElement CustomerSearch;
	
	//
	@FindBy(xpath="//label[@class='ng-binding']")
	public List<WebElement> Roles;
	

	public HomePage gotoHomepage(String role) throws InterruptedException {
		selectCheckbox(Roles, "Branch Manager");
		//ClickOn(Role_Checkbox);
		ClickOn(Continue_Button);
		//return PageFactory.initElements(driver, HomePage.class);
		HomePage homePage = new HomePage(driver, test);		
		PageFactory.initElements(driver, homePage);
		test.log(LogStatus.INFO, "Role selection -- success");
		
		isElementVisibile(CustomerSearch);
		return homePage;
	}

}
