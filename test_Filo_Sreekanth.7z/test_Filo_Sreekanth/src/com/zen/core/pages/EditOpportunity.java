package com.zen.core.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Constants;
import com.zen.utils.Keywords;

public class EditOpportunity extends Keywords{
	public  WebDriverWait wait = new WebDriverWait(this.driver, Constants.globalWait);
	public String content = "Opportunity updated successfully.";

	public EditOpportunity(WebDriver driver, ExtentTest test){
		super(driver, test);
	}
	
	@FindBy(xpath="//textarea[@name='comments']")
	public WebElement comments_textBox;
	
	@FindBy(xpath="//button[@class='primaryActionButton']")
	public WebElement submit_Button;
	
	@FindBy(xpath="//span[contains(.,'Opportunity Management')]")
	public WebElement OpportunityManagement_page;
	
	@FindBy(xpath="//button[contains(.,'Create')]")
	public WebElement Create_button;
	
	@FindBy(xpath="//input[@name='productName']")
	public WebElement productName;
	
	@FindBy(xpath="//div[text()='Individual']")
	public WebElement ProductCategories;
	//
	@FindBy(xpath="//li[@class='arrow ng-scope']")
	public List<WebElement> CategoriesList;
	
	
	@FindBy(xpath="//div[text()='Checking']")
	public WebElement Product;
	//
	@FindBy(xpath="//li[@class='arrow ng-scope']")
	public List<WebElement> ProductList;
	
	//
	@FindBy(xpath="//li[@class='roundedAdd ng-scope']")
	public List<WebElement> GroupList;
	
	
	@FindBy(xpath="//button[@data-ng-click='addProducts()']")
	public WebElement Product_DoneButton;
	
	@FindBy(xpath="//input[@name='assignee']")
	public WebElement AssignedTo;
	
	@FindBy(xpath="//select[@name='selectRegion']")
	public WebElement selectRegion;
	
	@FindBy(xpath="//select[@placeholder='Select Branch']")
	public WebElement SelectBranch;
	
	@FindBy(xpath="//div[text()='Branch Manager']")
	public WebElement SelectAssignee;
	
	@FindBy(xpath="//div[text()='Zenmonics JXCHG Tester']")
	public WebElement SelectAssignee1;
	//
	@FindBy(xpath="//div[@class='ui-grid-cell-contents ng-binding ng-scope']")
	public List<WebElement> Assignee;
	
	@FindBy(xpath="//button[@data-ng-click='applyAssignOpportunityModal()']")
	public WebElement Assign_Button;
	
	@FindBy(xpath="//textarea[@name='comments']")
	public WebElement comments;
	
	@FindBy(xpath="//select[@name='leadSource']")
	public WebElement leadSource;
	
	@FindBy(xpath="//select[@name='stage']")
	public WebElement stage;
	
	@FindBy(xpath="//select[@name='followUpType']")
	public WebElement followupType;
	
	@FindBy(xpath="//select[@name='status']")
	public WebElement status;
	
	/*@FindBy(xpath="//button[@data-ng-click='submitEditOpportunityModal()']")
	public WebElement editOpportunity_button;*/
	
	@FindBy(xpath="//div[@class='flexCenter']")
	public WebElement createOpportunity_success_message;
	
	@FindBy(xpath="//button[@class='primaryActionButton']")
	public WebElement createOpportunity_Done;
	
	// calenders
	@FindBy(xpath="//span[@ng-click='effDateOpen=!effDateOpen']")
	public WebElement effDate;
	
	@FindBy(xpath="//span[@ng-click='needeByDateOpen=!needeByDateOpen']")
	public WebElement needBYDate;
	
	@FindBy(xpath="//span[@ng-click='creationDateOpen=!creationDateOpen']")
	public WebElement creationDate;
	
	@FindBy(xpath="//span[@ng-click='effDateOpen=!effDateOpen']")
	public WebElement effectiveDate;
	
	
	
	@FindBy(xpath="//button[@data-ng-click='submitEditOpportunityModal()']")
	public WebElement editOpportunity_button;
	
	@FindBy(xpath="//select[@name='lostReason']")
	public WebElement lostReason;
	
	@FindBy(xpath="//div[text()='Please select Lost Reason']")
	public WebElement error_lostReason;
	
	public void datesel(){
		clickOnElement(effDate);
		datePicker("28-November 2016");
	}
	
	public void selectOMeffectiveDate(String effectiveDate) throws InterruptedException{
		clickOnElement(effDate);
		datePickernew(effectiveDate);
	}
	
	public void selectOMneededBYDate(String neededBYDate) throws InterruptedException{
		clickOnElement(needBYDate);
		datePickernew(neededBYDate);
	}
	
	//errors
		@FindBy(xpath="//h1[text()='We�re Sorry...']")
		public WebElement error_stage;
		@FindBy(xpath="//button[text()='OK']")
		public WebElement error_stage_OK;
		@FindBy(xpath="//p/p")
		public WebElement errorMessage;
		
	
	
	/*public OpportunityManagement addingOpportunity() throws InterruptedException{
		//AddCustomerName();
		AddProduct();
		AssignedTo();
		AddOpportunity_reminingData();
		createOpportunity_complete();
		takeScreenShot();
		OpportunityManagement opportunityManagement = new OpportunityManagement(driver, test);
		PageFactory.initElements(driver, opportunityManagement);
		return opportunityManagement;
	}
*/
	
	public void AddProduct(String categoriesList, String productList, String groupList) throws InterruptedException{
		//moveScrollToWebElement(productName);
		//isElementVisibile(productName);
		//wait.until(ExpectedConditions.visibilityOf(productName));
		ClickOnIcon(productName);
		isElementVisibile(ProductCategories);
		selectOption(CategoriesList, categoriesList);
		//clickOnElement(ProductCategories);
		isElementVisibile(Product);
		selectOption(ProductList, productList);
		//clickOnElement(Product);	
		selectOption(GroupList, groupList);
		//clickOnElement(ProductGroup);
		takeScreenShot();
		ClickOn(Product_DoneButton);		
	}
	
	public void editAssignedTo(String SelectRegion, String productList, String groupList) throws InterruptedException{
		//Thread.sleep(6000);
		//moveScrollToWebElement(AssignedTo);
		//isElementVisibile(AssignedTo);
		wait.until(ExpectedConditions.visibilityOf(AssignedTo)); 
		Thread.sleep(2000);
		ClickOnIcon(AssignedTo);
		isElementVisibile(selectRegion);
		moveScrollToWebElement(selectRegion);
		selectDropDownValue(selectRegion,SelectRegion);
		moveScrollToWebElement(Assign_Button);
		selectDropDownValue(SelectBranch,productList);
		Thread.sleep(2000);
		selectOption(Assignee, groupList);
		Thread.sleep(2000);
		moveScrollToWebElement(Assign_Button);
		ClickOn(Assign_Button);
	}

	public void editOpportunity_reminingData(String Comments,String LeadSource,String Stage,String FollowupType,String Status,String LostReason,String effectiveDate,String neededBYDate) throws InterruptedException{
		//isElementClickable(comments);
		EnterDataOnTextBox(comments, Comments);
		//Thread.sleep(2000);	
		//moveScrollToWebElement(leadSource);
		//wait.until(ExpectedConditions.visibilityOf(leadSource)); 
	
		selectDropDownValue(stage, Stage);
		//Stage validation
		if (Stage.equalsIgnoreCase("Closed")){
			Assert.assertTrue(error_stage.isDisplayed());
			error_stage_OK.click();
			selectDropDownValue(stage, Comments);
			test.log(LogStatus.PASS, "Getting error message 'Please select Lost Reason' while submitting without lost reason");
		}
		selectDropDownValue(leadSource, LeadSource);
		selectDropDownValue(status, Status);
		// Status validation
		if (Status.equalsIgnoreCase("Lost")){
			ClickOn(editOpportunity_button);
			isElementVisibile(error_lostReason);
			Assert.assertTrue(error_lostReason.isDisplayed());
			test.log(LogStatus.PASS, "Getting error message aftering selecting Status = Closed");
			selectDropDownValue(lostReason, LostReason);
		}
		
		wait.until(ExpectedConditions.visibilityOf(followupType));
		selectDropDownValue(followupType, FollowupType);	
		
		selectOMeffectiveDate(effectiveDate);
		selectOMneededBYDate(neededBYDate);
		takeScreenShot();
		
		ClickOn(editOpportunity_button);
		Thread.sleep(2000);
		try {
			//NeededByDate validation
			if (error_stage.isDisplayed()){			
				Assert.assertTrue(error_stage.isDisplayed());
				test.log(LogStatus.INFO, "NeededByDate - Validation popup has been displayed");
				error_stage_OK.click();
				selectOMneededBYDate(Comments);
				
				
				//test.log(LogStatus.PASS, "Message:--"+getWebelementText(errorMessage));
				test.log(LogStatus.PASS, "Getting error message while selecting 'NeededByDate' <= todays date");
				ClickOn(editOpportunity_button);
				Thread.sleep(2000);
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
	}
	
	

	public void editOpportunity_complete() throws InterruptedException{
		isElementClickable(createOpportunity_success_message);
		verifyTitle_Content(createOpportunity_success_message, this.content);
		takeScreenShot();
		ClickOn(createOpportunity_Done);			
	}	
	
	public OpportunityManagement editOpportunity(String comments) throws InterruptedException {
		EnterDataOnTextBox(comments_textBox, comments);
		moveScrollToWebElement(submit_Button);
		clickOnElement(submit_Button);
		moveScrollToWebElement(submit_Button);
		clickOnElement(submit_Button);
		OpportunityManagement opportunityManagement = new OpportunityManagement(driver, test);		
		PageFactory.initElements(driver, opportunityManagement);
		test.log(LogStatus.PASS, "Edit Opportunity -- success");
		
		isElementVisibile(OpportunityManagement_page);
		return opportunityManagement;
	}

}
