package com.zen.core.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class OpportunityManagement extends Keywords{

	public OpportunityManagement(WebDriver driver, ExtentTest test) {
		super(driver, test);
	}
	
	@FindBy(xpath="//span[@class='icon accentColor2'][text()='o']")
	public WebElement OM_Search_button;
	
	@FindBy(xpath="//select[@data-label='View By']")
	public WebElement searchOption_ViewBy;
	
	@FindBy(xpath="//button[@data-ng-click='searchReferrals()']")
	public WebElement searchButton;
	
	@FindBy(xpath="//span[@class='icon accentColor2'][text()='a']")
	public WebElement addButton;
	
	
	public Manage_Opportunities searchOpportunities(){
		isElementClickable(OM_Search_button);
		clickOnElement(OM_Search_button);
		isElementClickable(searchButton);
		selectDropDownValue(searchOption_ViewBy, "Created By Me");
		clickOnElement(searchButton);
		
		Manage_Opportunities manage_Opportunities = new Manage_Opportunities(driver, test);
		PageFactory.initElements(driver, manage_Opportunities);
		
		test.log(LogStatus.PASS, "Manage_Opportunities loading success");
		return manage_Opportunities;
	}
	
	public boolean addbuttonExists(){
		if (isElementVisibile(addButton)){
			return true;
		}
		return false;
	}

}
