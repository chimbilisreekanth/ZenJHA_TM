package com.zen.core.testCases;

import java.util.Hashtable;

import org.junit.AfterClass;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.zen.core.pages.HomePage;
import com.zen.utils.Constants;
import com.zen.utils.DataUtil;

public class EditRefferals extends BaseTests {
	private String className = this.getClass().getSimpleName();
	HomePage homePage = null;
	public int rowNo = 0;
	
	@BeforeTest
	public void loginToApp() throws Exception{
		test = extent.startTest("Test started:--"+className+"_"+rowNo);
		System.out.println("Test started:--"+className+"_"+rowNo);
		login();
	}

	@Test(dataProvider = "getData")
	public void EditRefferalsTest(Hashtable<String, String> data)
			throws Throwable {
		test = extent.startTest("Test started:--"+className+"_"+rowNo);
		if (!DataUtil.isSkip(className, Constants.TestCase_Xls_Path))
			throw new SkipException(Constants.TestCaseSkipMessage);

		// Run mode of Test Data
		if (data.get(Constants.Runmode).equals(Constants.Runmode_NO)) {
			throw new SkipException(Constants.DataSkipMessage);
		}
		try {
			/*invokeBrowser(data.get("Browser"));

			LaunchingPage launchingPage = new LaunchingPage(driver, test);
			PageFactory.initElements(driver, launchingPage);
			launchingPage.gotoLoginpage();

			Loginpage loginpage = new Loginpage(driver, test);
			PageFactory.initElements(driver, loginpage);
			launchingPage.WaitForPage(loginpage, loginpage.userName);

			Object page = loginpage.doLogin();
			if (page instanceof Loginpage)
				Assert.fail("Login fail -- credentials are incorrect");
			else if (page instanceof RolePage) {
				System.out.println("Login successfull");
			}
			test.log(LogStatus.INFO, "loginpage successfull");
			RolePage rolePage = (RolePage) page;
			loginpage.WaitForPage(rolePage, rolePage.Continue_Button);

			rolePage.gotoHomepage(data.get("role"));
			rolePage.takeScreenShot();

			homePage = new HomePage(driver, test);
			PageFactory.initElements(driver, homePage);
			rolePage.WaitForPage(homePage, homePage.Dashboard_Reminders);*/

			pages.homePage.loadcustomer(data.get("Customer"));
			test.log(LogStatus.INFO, "loaded customer successfull");
			pages.homePage.takeScreenShot();

			
			pages.homePage.WaitForPage(pages.menus, pages.menus.Cust_CompleteYourProfile_button);

			pages.menus.selectMenuItem(data.get("Menu"), data.get("MenuItem"));
			pages.menus.takeScreenShot();

			pages.manage_Opportunities.LoadOMs(data.get("Date"),data.get("ViewBy"));
			pages.manage_Opportunities.EditOM();

			pages.editOpportunity.editAssignedTo(data.get("SelectRegion"),
					data.get("selectBranch"), data.get("assignee"));
			pages.editOpportunity.editOpportunity_reminingData(data.get("Comments"),
					data.get("LeadSource"), data.get("Stage"),
					data.get("FollowupType"), data.get("Status"),data.get("LostReason"),data.get("effectiveDate"), data.get("neededBYDate"));
			pages.editOpportunity.editOpportunity_complete();

		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.FAIL, "Edit Refferals: -- Not Successfull  \n"
					+ e.getMessage());
			throw (e);
		}
	}

	@AfterMethod
	public void afterTest(ITestResult testResult) throws Exception {
		int result = testResult.getStatus();
		if (result == 3) {
			System.out.println("Skipped");
			rowNo++;
			DataUtil.setData(Constants.FILE_PATH,className, Constants.RESULT, rowNo,
					Constants.KEYWORD_SKIP);
			test.log(LogStatus.SKIP, "Skipped due to Runmode Set to 'NO':--"
					+ className.toString());
		} else if (result == 2) {
			rowNo++;
			DataUtil.setData(Constants.FILE_PATH,className, Constants.RESULT, rowNo,
					Constants.KEYWORD_FAIL + " ");
			test.log(LogStatus.FAIL,
					"Failed Test Case:--" + className.toString());
			homePage.takeScreenShot();
		} else if (result == 1) {
			rowNo++;
			DataUtil.setData(Constants.FILE_PATH,className, Constants.RESULT, rowNo,
					Constants.KEYWORD_PASS);
			test.log(LogStatus.PASS,
					"Passed Test Case:--" + className.toString());
			homePage.takeScreenShot();
		}
		if (extent != null) {
			extent.endTest(test);
			extent.flush();
		}
		if (driver != null)
			driver.quit();
	}

	@AfterClass
	public void logoutApp() {
		if (extent != null) {
			extent.endTest(test);
			extent.flush();
		}
		if (driver != null)
			driver.quit();
	}

	@DataProvider(name = "getData")
	public Object[][] getData() throws Exception {
		return DataUtil.getData(className, Constants.FILE_PATH);
	}

}
