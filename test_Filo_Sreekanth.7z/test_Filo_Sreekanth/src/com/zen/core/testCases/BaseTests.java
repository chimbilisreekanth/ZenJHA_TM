package com.zen.core.testCases;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.core.pages.AllPages;
import com.zen.core.pages.Loginpage;
import com.zen.core.pages.RolePage;
import com.zen.utils.Constants;
import com.zen.utils.ExtentManager;
import com.zen.utils.Xls_Reader;

public class BaseTests {
	public WebDriver driver;
	public ExtentReports extent = ExtentManager.getInstance();
	//public Xls_Reader xls = new Xls_Reader(Constants.FILE_PATH);
	public ExtentTest test;
	public WebDriverWait wait;
	public static Properties properties;
	public AllPages pages;
	
	public void login() throws InterruptedException, IOException{
		Properties prop = loadProperties(Constants.CORE_PROPERTIES_FILE_PATH);
		invokeBrowser(prop.getProperty("browser"));
		pages = new AllPages(driver, test);
		pages.launchingPage.gotoLoginpage(prop.getProperty("coreURL"));
		pages.launchingPage.WaitForPage(pages.loginpage, pages.loginpage.userName);
		
		Object page = pages.loginpage.doLogin(prop.getProperty("core_UserName"),prop.getProperty("core_Pwd"));			
		if (page instanceof Loginpage)
			Assert.fail("Login fail -- credentials are incorrect");
		else if (page instanceof RolePage) {
			System.out.println("Login successfull");
		}
		pages.loginpage.WaitForPage(pages.rolePage, pages.rolePage.Continue_Button);
		pages.rolePage.gotoHomepage(prop.getProperty("role"));
		pages.rolePage.WaitForPage(pages.homePage, pages.homePage.CustomerSearch);
		pages.rolePage.takeScreenShot();
	}
	
	public void invokeBrowser(String bType) throws InterruptedException{
		switch (bType) {
		case "ff":
			driver = new FirefoxDriver();
			test.log(LogStatus.INFO, "Firefox - browser has been opened");
			break;
		case "ch":
			System.setProperty("webdriver.chrome.driver", Constants.chromedriver);
			driver = new ChromeDriver();
			test.log(LogStatus.INFO, "Chrome - browser has been opened");
			break;
		case "ie":
			System.setProperty("webdriver.ie.driver", Constants.iedriver);
			driver = new InternetExplorerDriver();
			test.log(LogStatus.INFO, "InternetExplorer - browser has been opened");
			//Thread.sleep(10000);
			break;

		default:
			System.out.println("There is no value for Browser, hence invoking Firefox broser");
			driver = new FirefoxDriver();
			test.log(LogStatus.INFO, "Firefox - browser has been opened");
			break;
		}		
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(Constants.globalWait, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(120, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
	}
	
	public boolean isElementVisibile(WebElement element)
	{
		boolean bExists=false;
		try{
			wait = new WebDriverWait(this.driver,10);   
			wait.until(ExpectedConditions.visibilityOf(element));
			bExists=true;
		}
		catch (Exception e){
		}
		return bExists;
	}
	
	public Properties loadProperties(String PROPERTIES_FILE_PATH){
		File file = new File(PROPERTIES_FILE_PATH);		  
		FileInputStream fileInput = null;
		Properties prop = null;
		try {
			prop = new Properties();
			fileInput = new FileInputStream(file);
			prop.load(fileInput);
		} catch (Exception e) {
			e.printStackTrace();
		}	
		return prop;
	}	
	
}
