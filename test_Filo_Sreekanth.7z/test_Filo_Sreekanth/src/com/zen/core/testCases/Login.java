package com.zen.core.testCases;

import java.util.Hashtable;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.zen.core.pages.LaunchingPage;
import com.zen.utils.Constants;
import com.zen.utils.DataUtil;

public class Login extends BaseTests {
	private String className=this.getClass().getSimpleName();
	LaunchingPage launchingPage=null;
	public int rowNo=0;
	
	@Test(dataProvider="getData")
	public void login(Hashtable<String,String> data) throws Throwable {		
	try{
		test = extent.startTest("Test started:--"+className+"_"+rowNo);
		System.out.println("Test started:--"+className+"_"+rowNo);
		login();		
		} catch (Exception e) {
		e.printStackTrace();
		test.log(LogStatus.FAIL, "Login to mBanker: -- Not Successfull /n"+e.getMessage());
		throw(e);
		}
	}
	
	@AfterMethod
	public void afterTest(ITestResult testResult) throws Exception{
		int result=testResult.getStatus();
				
		if(result==3){
			System.out.println("Skipped");
			rowNo++;
			DataUtil.setData(Constants.FILE_PATH,className,Constants.RESULT,rowNo,Constants.KEYWORD_SKIP);
			test.log(LogStatus.SKIP, "Skipped due to Runmode Set to 'NO':--"+className.toString());
		}
		else if(result==2)
		    {
			rowNo++;
			DataUtil.setData(Constants.FILE_PATH,className,Constants.RESULT,rowNo,Constants.KEYWORD_FAIL+" ");
			test.log(LogStatus.FAIL, "Failed Test Case:--"+className.toString());
			launchingPage.takeScreenShot();
			}
		else if(result==1){
			rowNo++;
			DataUtil.setData(Constants.FILE_PATH,className,Constants.RESULT,rowNo,Constants.KEYWORD_PASS);
			test.log(LogStatus.PASS, "Passed Test Case:--"+className.toString());
			launchingPage.takeScreenShot();
		}
		
		if (extent != null) {
			extent.endTest(test);
			extent.flush();
		}
		if(driver!=null)
		driver.quit();
	}	
		
	@DataProvider(name="getData")
	public Object[][] getData() throws Exception
	{
		return DataUtil.getData(className,Constants.FILE_PATH);
	}

}
