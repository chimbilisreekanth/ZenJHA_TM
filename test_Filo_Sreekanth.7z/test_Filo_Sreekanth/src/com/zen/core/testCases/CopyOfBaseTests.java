package com.zen.core.testCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.ExtentManager;
import com.zen.utils.Xls_Reader;
import com.zen.utils.Constants;

public class CopyOfBaseTests {
	public WebDriver driver;
	public ExtentReports extent = ExtentManager.getInstance();
	public Xls_Reader xls = new Xls_Reader(Constants.FILE_PATH);
	public ExtentTest test;
	
	public void invokeBrowser(String bType) throws InterruptedException{
		switch (bType) {
		case "firefox":
			driver = new FirefoxDriver();
			test.log(LogStatus.INFO, "Firefox - browser has been opened");
			break;
		case "chrome":
			System.setProperty("webdriver.chrome.driver", Constants.chromedriver);
			driver = new ChromeDriver();
			test.log(LogStatus.INFO, "Chrome - browser has been opened");
			break;
		case "ie":
			System.setProperty("webdriver.ie.driver", Constants.iedriver);
			driver = new InternetExplorerDriver();
			test.log(LogStatus.INFO, "InternetExplorer - browser has been opened");
			//Thread.sleep(10000);
			break;

		default:
			System.out.println("There is no value for Browser, hence invoking Firefox broser");
			driver = new FirefoxDriver();
			test.log(LogStatus.INFO, "Firefox - browser has been opened");
			break;
		}		
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(400, TimeUnit.SECONDS);
		driver.manage().timeouts().setScriptTimeout(120, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
	}
}
