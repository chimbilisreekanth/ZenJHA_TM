package com.zen.bnc.testCases;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.zen.bnc.pages.Loginpage;
import com.zen.utils.BaseTests;
import com.zen.utils.Constants;
import com.zen.utils.DataUtil;

public class Fillo_Test_1 extends BaseTests {
	private String className = this.getClass().getSimpleName();
	Loginpage loginpage = null;
	public int rowNo = 1;
	public String Scenarioid = null;
	Properties prop;

	String rm_tc = "Select * from TestCases";
	String tc_data = "Select * from " + className + "";

	@BeforeTest
	public void loginToBnc() throws Throwable {
		prop = loadProperties(Constants.BNC_PROPERTIES_FILE_PATH);		
		String timeStamp = new SimpleDateFormat("yyyyMMddHHmmss").format(Calendar.getInstance().getTime());
		FileUtils.copyDirectory(new File(Constants.REPORTS_PATH), new File(Constants.BACKUP_REPORTS_PATH+timeStamp+"\\"));
		FileUtils.cleanDirectory(new File(Constants.REPORTS_PATH));
	}

	@Test(dataProvider = "getData")
	public void AccountOpen(Hashtable<String, String> data) throws Throwable {
		Scenarioid = data.get("Scenario");
		test = extent.startTest("Test started:--" + className + "_" + rowNo);
		try {
			// Check the run mode of test data if 'yes' execute TC otherwise
			// SkipException
			if (data != null
					&& data.get(Constants.Runmode) != null
					&& data.get(Constants.Runmode) .equals(Constants.Runmode_YES)) {

				// Test case
				invokeBrowser(prop.getProperty("browser"));

			} else {
				throw new SkipException(Constants.DataSkipMessage);
			}
		} catch (Exception e) {
			e.printStackTrace();
			UpdateResults_Validations(Scenarioid, className, rowNo);
			test.log(LogStatus.FAIL, "Failed Test Case:--" + className + "-"
					+ rowNo + e.getMessage());
			throw (e);
		}
	}

	@AfterMethod
	public void afterTest(ITestResult testResult) throws Exception {
		UpdateResults(testResult, Scenarioid, className, rowNo);
		rowNo++;
		if (driver != null)
			driver.quit();
	}

	@AfterTest
	public void TearDown() {
		if (extent != null) {
			extent.endTest(test);
			extent.flush();
		}
	}

	@DataProvider(name = "getData")
	public Object[][] getData() throws Exception {
		// Check the run mode of test case if 'yes' read the data from test data
		// file otherwise SkipException
		if (DataUtil.Skip(Constants.bnc_TestCase_Xls_Path, rm_tc, className)) {
			return DataUtil.getDataDup(Constants.bnc_FILE_PATH, tc_data);
		} else {
			throw new SkipException(Constants.TestCaseSkipMessage);
		}
	}
}
