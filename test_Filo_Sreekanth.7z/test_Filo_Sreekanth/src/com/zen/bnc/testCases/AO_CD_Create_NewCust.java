package com.zen.bnc.testCases;

import java.io.File;
import java.util.Hashtable;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.LogStatus;
import com.zen.bnc.pages.AllPages;
import com.zen.bnc.pages.Loginpage;
import com.zen.bnc.pages.RolePage;
import com.zen.utils.BaseTests;
import com.zen.utils.Constants;
import com.zen.utils.DataUtil;

public class AO_CD_Create_NewCust extends BaseTests {
	private String className = this.getClass().getSimpleName();
	Loginpage loginpage = null;
	public int rowNo = 0;
	Properties prop;
	
	
	@BeforeTest
	public void loginToBnc() throws Exception{	
		prop = loadProperties(Constants.BNC_PROPERTIES_FILE_PATH);
		FileUtils.cleanDirectory(new File(Constants.REPORTS_PATH));
	}
	
	@Test(dataProvider = "getData")
	public void AccountOpen(Hashtable<String, String> data)	throws Throwable {
		test = extent.startTest("Test started:--"+className+"_"+rowNo);
		// Run mode of Test Cases
		if (!DataUtil.isSkip(className, Constants.bnc_TestCase_Xls_Path))
			throw new SkipException(Constants.TestCaseSkipMessage);
		// Run mode of Test Data
		if (data.get(Constants.Runmode).equals(Constants.Runmode_NO)) {
			throw new SkipException(Constants.DataSkipMessage);
		}
		try {	
			invokeBrowser(prop.getProperty("browser"));			
			pages = new AllPages(driver, test);
			pages.launchingPage.gotoLoginpage(prop.getProperty("bncURL"));
			pages.launchingPage.WaitForPage(pages.loginpage, pages.loginpage.userName);
			
			Object page = pages.loginpage.doLogin(prop.getProperty("bnc_UserName"),prop.getProperty("bnc_Pwd"));			
			if (page instanceof Loginpage)
				Assert.fail("Login Fail -- credentials are incorrect");
			else if (page instanceof RolePage) {
				System.out.println("Login Pass -- credentials are correct");
			}
			pages.loginpage.WaitForPage(pages.rolePage, pages.rolePage.Continue_Button);
			pages.rolePage.gotoHomepage(prop.getProperty("role"));
			
			pages.rolePage.WaitForPage(pages.selectLocation, pages.selectLocation.btn_Continue);
			pages.selectLocation.gotoHomePage(prop.getProperty("region"), prop.getProperty("branch"));
			
			pages.selectLocation.WaitForPage(pages.homePage, pages.homePage.CustomerSearch);
			pages.homePage.WaitForPage(pages.menus, pages.menus.menuIcon);
			pages.menus.gotoModule(data.get("Menu"), data.get("MenuItem"));
			pages.menus.takeScreenShot();	
			
			pages.menus.WaitForPage(pages.aO_LetsGetStarted, pages.aO_LetsGetStarted.button_NewApplication);
			pages.aO_LetsGetStarted.verifyPageload_LetsGetStarted();
			pages.aO_LetsGetStarted.ao_productSelection(data.get("appType"));
						
			pages.aO_LetsGetStarted.WaitForPage(pages.aO_ProductSelection, pages.aO_ProductSelection.button_Continue);
			pages.aO_ProductSelection.verifyPageload_ProductSelection();	
			pages.aO_ProductSelection.productSelection(data.get("ProductType"),data.get("Productmenu"),data.get("Product"));
			pages.aO_ProductSelection.goto_AccountOwnership();
						
			pages.aO_ProductSelection.WaitForPage(pages.aO_accountOwnership, pages.aO_accountOwnership.button_Addapplicant);
			pages.aO_accountOwnership.verifyPageload_AccountOwnership();
			pages.aO_accountOwnership.productSelection(data.get("Ownership"));
			pages.aO_accountOwnership.Addapplicant(data.get("custType"),data.get("Addapplicant"));
			pages.aO_accountOwnership.button_Continue();
			//pages.aO_accountOwnership.navigate_Alittlebitabout();
				
			pages.aO_accountOwnership.WaitForPage(pages.aO_Alittlebitabout, pages.aO_Alittlebitabout.button_Continue);
			pages.aO_Alittlebitabout.navigate_Alittlebitmoreabout(data.get("info-LB"));
			
			pages.aO_Alittlebitabout.WaitForPage(pages.aO_Alittlebitmoreabout, pages.aO_Alittlebitmoreabout.button_Continue);
			pages.aO_Alittlebitmoreabout.navigate_formsofidentification(data.get("info-LBM-Buss"),data.get("info-LBM-Prsnl"));
					
			pages.aO_Alittlebitmoreabout.WaitForPage(pages.aO_formsofidentification, pages.aO_formsofidentification.button_Continue);
			pages.aO_formsofidentification.navigate_BSA(data.get("info-FOI"));
			
			// School/Employer information page has been removed.
			/*pages.aO_formsofidentification.WaitForPage(pages.aO_Schoolinformation, pages.aO_Schoolinformation.button_Continue);			
			pages.aO_Schoolinformation.navigate_BSA(data.get("Occupation"),data.get("employerName"),data.get("phone"),data.get("state"),data.get("city"),data.get("zipCodeE"));
			*/	
			pages.aO_formsofidentification.WaitForPage(pages.aO_BSA, pages.aO_BSA.button_Continue);		
			pages.aO_BSA.navigate_AO_ApplicationDefaults(data.get("info-custBSA"));
			
			/*//POD Page
			pages.aO_BSA.WaitForPage(pages.aO_Pod, pages.aO_Pod.button_Continue);
			pages.aO_Pod.navigate_AO_ApplicationDefaults(data.get("info-pod"));*/
			
			if(isElementVisibile(pages.aO_creditcheckpopup.btn_GotoApplicationManagement)){
				//credit check pages
				pages.aO_BSA.WaitForPage(pages.aO_creditcheckpopup,pages.aO_creditcheckpopup.btn_GotoApplicationManagement);
				pages.aO_creditcheckpopup.navigate_AppManagement();
				
				pages.aO_creditcheckpopup.WaitForPage(pages.aO_AppManagement,pages.aO_AppManagement.btn_Lock);
				pages.aO_AppManagement.navigate_ApplicationDefaults(data.get("info-AppMngmnt"));
				//end credit check pages
			}
			
			pages.aO_Pod.WaitForPage(pages.aO_ApplicationDefaults, pages.aO_ApplicationDefaults.PrimaryOfficer);			
			pages.aO_ApplicationDefaults.navigate_AccountDefaults(data.get("info-Appdefaults"));
			
			pages.aO_ApplicationDefaults.WaitForPage(pages.aO_AccountDefaults, pages.aO_AccountDefaults.button_Continue);			
			pages.aO_AccountDefaults.navigate_AO_BSA_Product(data.get("info-acctdefualts"));
			
			pages.aO_AccountDefaults.WaitForPage(pages.aO_BSA_Product, pages.aO_BSA_Product.button_Continue);			
			pages.aO_BSA_Product.navigate_Depositmoney_Product(data.get("info-acctBSA"));
			
			pages.aO_BSA_Product.WaitForPage(pages.aO_Certificateproductdetails, pages.aO_Certificateproductdetails.button_Continue);
			pages.aO_Certificateproductdetails.navigateTo_AO_Depositmoney_Product(data.get("info-CD"));
			
			pages.aO_Certificateproductdetails.WaitForPage(pages.aO_Depositmoney_Product, pages.aO_Depositmoney_Product.button_Back);			
			pages.aO_Depositmoney_Product.navigate_AO_Depositmoney(data.get("AO_Depositmoney"));
			
			pages.aO_Depositmoney_Product.WaitForPage(pages.aO_Depositmoney, pages.aO_Depositmoney.button_Continue);			
			pages.aO_Depositmoney.navigate_Services(data.get("info-DepMny"));
			
			pages.aO_Depositmoney.WaitForPage(pages.aO_Services, pages.aO_Services.button_Continue);			
			pages.aO_Services.navigate_Disclosures();
			
			pages.aO_Services.WaitForPage(pages.aO_Disclosures, pages.aO_Disclosures.button_Continue);			
			pages.aO_Disclosures.navigate_finalPage();
			
			pages.aO_Disclosures.WaitForPage(pages.aO_finalPage, pages.aO_finalPage.text_ApplicantName);			
			pages.aO_finalPage.takeScreenShot();
			pages.aO_finalPage.Ao_complete();			
			
			System.out.println("AO completed successfully");
			
		} catch (Exception e) {
			e.printStackTrace();
			test.log(LogStatus.FAIL,"Failed Test Case:--"+className+"-"+rowNo+e.getMessage());
			throw (e);
		}
	}

	@AfterMethod
	public void afterTest(ITestResult testResult) throws Exception {
		int result = testResult.getStatus();
		if (result == 3) {
			rowNo++;
			DataUtil.setData(Constants.bnc_FILE_PATH,className, Constants.RESULT, rowNo,Constants.KEYWORD_SKIP);
			System.out.println("Skipped Test Case:--"+className+"-"+rowNo);
			test.log(LogStatus.SKIP, "Skipped due to Runmode Set to 'NO':--"+className+"-"+rowNo);
		} else if (result == 2) {
			rowNo++;
			DataUtil.setData(Constants.bnc_FILE_PATH,className, Constants.RESULT, rowNo,Constants.KEYWORD_FAIL + " ");
			System.out.println("Failed:--"+className+"-"+rowNo);
			test.log(LogStatus.FAIL,"Failed Test Case:--"+className+"-"+rowNo);
			pages.loginpage.takeScreenShot();
		} else if (result == 1) {
			rowNo++;
			//DataUtil.setData(Constants.bnc_FILE_PATH,className, Constants.RESULT, rowNo,Constants.KEYWORD_PASS);
			DataUtil.setData(Constants.bnc_FILE_PATH,className, Constants.RESULT, rowNo,pages.aO_finalPage.resultStatus());
			System.out.println("Pass Test Case:--"+className+"-"+rowNo);
			DataUtil.setData(Constants.bnc_FILE_PATH,className, Constants.ID, rowNo, pages.aO_finalPage.result());
			test.log(LogStatus.PASS,"Passed Test Case:--"+className+"-"+rowNo);
			}		
		if (driver != null)
			driver.quit();
		
	}
	@AfterTest
	public void TearDown(){
		if (extent != null){
			extent.endTest(test);
			extent.flush();
		}		
	}
	@DataProvider(name = "getData")
	public Object[][] getData() throws Exception {
		return DataUtil.getData(className, Constants.bnc_FILE_PATH);
	}
}
