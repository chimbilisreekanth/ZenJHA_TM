package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_formsofidentification extends Keywords{

	public AO_formsofidentification(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//select[@aria-label='Identification Type']")
	public WebElement dd_IdentificationType;
	
	@FindBy(xpath="//select[@aria-label='Identification Type'][@disabled='disabled']")
	public WebElement dd_IdentificationTypedisabled;
	
	@FindBy(xpath="//input[@aria-label='ID Number']")
	public WebElement tb_IDNumber;
	
	@FindBy(xpath="//select[@name='state0']")
	public WebElement dd_IssuingState;
	
	@FindBy(xpath="//span[@data-ng-click='fromDtOpen=!fromDtOpen']")
	public WebElement date_fromDtOpen;
	
	@FindBy(xpath="//span[@data-ng-click='toDtOpen=!toDtOpen']")
	public WebElement date_toDtOpen;
	
	@FindBy(xpath="//select[@data-label='CIP Verified']")
	public WebElement dd_CIPVerified;
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_Schoolinformation_title;
		
	@FindBy(xpath="//input[@aria-label=' Occupation']")
	public WebElement Occupation;
	
	@FindBy(xpath="//input[@name='employerName']")
	public WebElement employerName;
	
	@FindBy(xpath="//input[@name='phone']")
	public WebElement phone;
	
	@FindBy(xpath="//select[@name='state']")
	public WebElement state;
	
	@FindBy(xpath="//input[@name='city']")
	public WebElement city;
	
	@FindBy(xpath="//input[@name='zipCode']")
	public WebElement zipCode;
	
	@FindBy(xpath="//input[@name='primary']")
	public WebElement Address;
	
	@FindBy(xpath="//input[@name='issuedDate0']")
	public WebElement issuedDate;
	
	@FindBy(xpath="//input[@name='expDate0']")
	public WebElement expDate;
	
	/*@FindBy(xpath="//h1[@id='WLdialogTitle']")
	public WebElement err_popup;
	@FindBy(xpath="//button[contains(.,'OK')]")
	public WebElement err_Ok_button;*/
	
	public void verifyPageload_AO_BSA() throws InterruptedException{
		verifyTitle_Content(AO_Schoolinformation_title, "School");		
	}	
	
	public AO_BSA navigate_BSA(String infoFOI) throws InterruptedException{
		String spliter[] = infoFOI.split(",");
		String idtype = spliter[0];
		String idNumber = spliter[1];
		String issuedState = spliter[2];
		String CIPVerified = spliter[3];
		handle_weAreSorry();
						
		isElementVisibile(tb_IDNumber);
		if(!isElementVisibile(dd_IdentificationTypedisabled)){
			selectDropDownValue(dd_IdentificationType, idtype);
		}		  
		EnterDataOnTextBox(tb_IDNumber, idNumber);
		if(isElementVisibile(dd_IssuingState)){
			selectDropDownValue(dd_IssuingState, issuedState);	
		}		
		EnterDataOnTextBox(issuedDate,getPrevWorkingDayfromCurrentDate());
		//ClickOnCheckbox(date_fromDtOpen);
		//datePickernew(fromDtOpen);
		EnterDataOnTextBox(expDate,getCustomDateFuture(10, "Y"));
		//ClickOnCheckbox(date_toDtOpen);
		//datePickernew(toDtOpen);
		
		if (isElementVisibile(dd_CIPVerified)){
			selectDropDownValue(dd_CIPVerified, CIPVerified);
		}
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_BSA Method Execution");
		AO_BSA ao_BSA = new AO_BSA(driver, test);		
		PageFactory.initElements(driver, ao_BSA);		
		return ao_BSA;
	}
	
	
	/*public AO_Schoolinformation navigate_Schoolinformation(String idtype,String idnum,String issuedState,String fromDtOpen,String toDtOpen) throws InterruptedException{
		handle_weAreSorry();
		if (isElementVisibile(dd_CIPVerified)){
			selectDropDownValue(dd_CIPVerified, "NO");
		}
		if(isElementVisibile(tb_IDNumber)){
		selectDropDownValue(dd_IdentificationType, idtype);  
		clearData_Textfield(tb_IDNumber);
		EnterDataOnTextBox(tb_IDNumber, "12345");
		selectDropDownValue(dd_IssuingState, issuedState); 
		ClickOnCheckbox(date_fromDtOpen);
		datePickernew(fromDtOpen); 
		ClickOnCheckbox(date_toDtOpen);
		datePickernew(toDtOpen); 
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_Schoolinformation Method Execution");
		}
		
		AO_Schoolinformation ao_Schoolinformation = new AO_Schoolinformation(driver, test);		
		PageFactory.initElements(driver, ao_Schoolinformation);
		return ao_Schoolinformation;
	}*/


}
