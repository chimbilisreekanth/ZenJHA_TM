package com.zen.bnc.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_BSA extends Keywords{

	public AO_BSA(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_BSA_title;	
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//span[@data-ng-click='bsaCtrl.clickInternetBanking(true)']")
	public WebElement option_Internetbanking;
	
	@FindBy(xpath="//span[@data-ng-click='bsaCtrl.clickForeignCitizen(false)']")
	public WebElement optins_foreigncountry;
	
	@FindBy(xpath="//label[@for='status2']")
	public WebElement EmploymentStatus;
	
	@FindBy(xpath="//select[@aria-label='Personal account purpose?']")
	public WebElement Personalaccountpurpose;
	
	// Personal - Product
	@FindBy(xpath="//p[contains(.,'Does the customer use Internet banking?')]")
	public WebElement option_customeruseInternetbanking;
	
	@FindBy(xpath="//p[contains(.,'Does the customer use Internet banking?')]")
	public WebElement option_internetbanking;
	
	
	@FindBy(xpath="//textarea[@data-ng-model='question.proposition.answer']")
	public WebElement txtbx_Retiredfrom;
	
	@FindBy(xpath="//div[1]/div[2]/span/span")
	public List<WebElement> options_PersonType;
	
	@FindBy(xpath="//div[2]/div[2]/span/span")
	public List<WebElement> options_Internetbanking;
	
	@FindBy(xpath="//div[3]/div[2]/span/span")
	public List<WebElement> options_citizenofaforeigncountry;
	
	@FindBy(xpath="//div[5]/div[2]/span/span")
	public List<WebElement> options_Employed;
	
	@FindBy(xpath="//div[4]/div[2]/span/span")
	public List<WebElement> options_EmploymentStatus;
	
	// Business - Product
	@FindBy(xpath="//select[@aria-label='What industry is your business a part of? ']")
	public WebElement dd_Whatindustryisyourbusinessapartof;
	
	@FindBy(xpath="//div[3]/textarea")
	public WebElement dd_CountryStateIncorporated;
	
	@FindBy(xpath="//div[4]/textarea")
	public WebElement txtbx_natureofthebusiness;
	
	@FindBy(xpath="//input[@type='text']")
	public WebElement txtbx_NumberofEmployees;
	
	@FindBy(xpath="//input[@type='number']")
	public WebElement dd_NumbeofEmployees;	
	
	@FindBy(xpath="//div[6]/textarea")
	public WebElement txtbx_PrimaryLocationofOperation;
	
	@FindBy(xpath="//div[7]/textarea")
	public WebElement txtbx_DescofPrimaryCustomer;
	
	@FindBy(xpath="//div[8]/textarea")
	public WebElement txtbx_ActivityExpectations;
	
	@FindBy(xpath="//div[9]/div[2]/span/span")
	public List<WebElement> options_MSBtypeservices;
	
	@FindBy(xpath="//div[10]/div[2]/span/span")
	public List<WebElement> options_charitableorganization;
	
	@FindBy(xpath="//div[11]/div[2]/span/span")
	public List<WebElement> options_seniorforeignpoliticalfigure;
	
	@FindBy(xpath="//div[12]/div[2]/span/span")
	public List<WebElement> options_liveoutsideofourservicearea;
	
	@FindBy(xpath="//div[13]/div[2]/span/span")
	public List<WebElement> options_originateach;
	
	@FindBy(xpath="//div[14]/div[2]/span/span")
	public List<WebElement> options_operateATMs;
	
	/*@FindBy(xpath="//div[15]/div[2]/span/span")
	public List<WebElement> options_vendor;*/
	
	@FindBy(xpath="//div[15]/div[2]/span/span")
	public List<WebElement> options_cashChecksforyourcustomers;
	
	@FindBy(xpath="//div[16]/div[2]/span/span")
	public List<WebElement> options_sellredeemmoneyorders;
	
	@FindBy(xpath="//div[17]/div[2]/span/span")
	public List<WebElement> options_wiremoney;
	
	@FindBy(xpath="//div[18]/div[2]/span/span")
	public List<WebElement> options_currencyDealer_Exchanger;
	
	@FindBy(xpath="//div[19]/div[2]/span/span")
	public List<WebElement> options_officeoutsidetheUnitedStates;
	
	@FindBy(xpath="//div[20]/div[2]/span/span")
	public List<WebElement> options_transactionsotherthanUnitedStates;
	
	@FindBy(xpath="//div[21]/div[2]/span/span")
	public List<WebElement> options_PSP;
	
	@FindBy(xpath="//div[22]/div[2]/span/span")
	public List<WebElement> options_traveloutsideUS;
	
	@FindBy(xpath="//div[23]/div[2]/span/span")
	public List<WebElement> options_interestedinRDC;
	
	@FindBy(xpath="//div[24]/div[2]/span/span")
	public List<WebElement> options_bets_wagers;
	
	
	@FindBy(xpath="//select[@data-label='Occupation Category']")
	public WebElement dd_OccupationCategory;
	
	@FindBy(xpath="//textarea[@data-ng-model='question.proposition.answer']")
	public WebElement txtbx_OccupationDescription;
	
	
	public void verifyPageload_AO_BSA() throws InterruptedException{
		verifyTitle_Content(AO_BSA_title, "BSA");		
	}	
	
	// for 2 product
	public AO_information navigate_information(String acctpurpose) throws InterruptedException{
		Thread.sleep(2000);
		handle_weAreSorry();
		Thread.sleep(2000);
		/*isElementVisibile(option_Personal);
		moveScrollToWebElement(option_Internetbanking);
		clickOnElement(option_Internetbanking);
		clickOnElement(optins_foreigncountry);
		ClickOnCheckbox(EmploymentStatus);		
		selectDropDownValue(Personalaccountpurpose, acctpurpose);*/
		clickOnElement(button_Continue);
		
		AO_information ao_information = new AO_information(driver, test);		
		PageFactory.initElements(driver, ao_information);		
		return ao_information;
	}
	
	// for 1 product
	public AO_ApplicationDefaults navigate_AO_ApplicationDefaults(String info) throws InterruptedException{
		String spliter[] = info.split(",");
		//personal
		String option_no = spliter[0];
		String option_yes = spliter[1];
		String PersonType = spliter[2];
		String EmploymentStatus = spliter[3];
		String Retiredfrom = spliter[4];
		String OccupationCategory = spliter[9];
		String OccupationDescription = spliter[10];
		// business
		String businessapartof = spliter[5];
		String state = spliter[6];
		String numberofEmployees = spliter[7];
		String Desc = spliter[8];
		
		handle_weAreSorry();
		//for Personal product
		if(isElementVisibile(option_internetbanking)){			
			selectOption(options_PersonType, PersonType);
			selectOption(options_Internetbanking, option_no);
			selectOption(options_citizenofaforeigncountry, option_no);
			selectOption(options_EmploymentStatus, EmploymentStatus);
			if (EmploymentStatus.equalsIgnoreCase("Retired")){
				selectOption(options_EmploymentStatus, EmploymentStatus);
				EnterDataOnTextBox(txtbx_Retiredfrom, Retiredfrom);
			}
			if (EmploymentStatus.equalsIgnoreCase("Employed")){
				selectOption(options_EmploymentStatus, EmploymentStatus);
				selectDropDownValue(dd_OccupationCategory, OccupationCategory);
				EnterDataOnTextBox(txtbx_OccupationDescription, OccupationDescription);
			}			
		}
		//for Business product
		if(isElementVisibile(dd_Whatindustryisyourbusinessapartof)){	
			selectOption(options_PersonType, "Business");
			selectDropDownValue(dd_Whatindustryisyourbusinessapartof, 1);
			EnterDataOnTextBox(dd_CountryStateIncorporated, state);
			EnterDataOnTextBox(txtbx_natureofthebusiness, businessapartof);
			EnterDataOnTextBox(txtbx_NumberofEmployees, numberofEmployees);
			//EnterDataOnTextBox(txtbx_CountryState, state);
			//EnterDataOnTextBox(txtbx_natureofthebusiness, businessapartof);			
			/*isElementVisibile(dd_NumbeofEmployees);
			EnterDataOnTextBox(dd_NumbeofEmployees, numberofEmployees);*/
			EnterDataOnTextBox(txtbx_PrimaryLocationofOperation, state);
			EnterDataOnTextBox(txtbx_DescofPrimaryCustomer, Desc);
			EnterDataOnTextBox(txtbx_ActivityExpectations, Desc);			
			
			selectOption(options_MSBtypeservices, option_no);
			selectOption(options_charitableorganization, option_no);
			selectOption(options_seniorforeignpoliticalfigure, option_no);
			selectOption(options_liveoutsideofourservicearea, option_no);
			selectOption(options_originateach, option_no);
			selectOption(options_operateATMs, option_no);
			//selectOption(options_vendor, "Customer");
			selectOption(options_cashChecksforyourcustomers, option_no);
			selectOption(options_sellredeemmoneyorders, option_no);
			selectOption(options_wiremoney, option_no);
			selectOption(options_currencyDealer_Exchanger, option_no);
			selectOption(options_officeoutsidetheUnitedStates, option_no);
			selectOption(options_transactionsotherthanUnitedStates, option_no);
			selectOption(options_PSP, option_no);
			selectOption(options_traveloutsideUS, option_no);
			selectOption(options_interestedinRDC, option_no);
			selectOption(options_bets_wagers, option_no);			
		}
		moveScrollToWebElement(button_Continue);
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_AO_ApplicationDefaults Method Execution");
		
		AO_ApplicationDefaults ao_ApplicationDefaults = new AO_ApplicationDefaults(driver, test);		
		PageFactory.initElements(driver, ao_ApplicationDefaults);		
		return ao_ApplicationDefaults;
	}

}
