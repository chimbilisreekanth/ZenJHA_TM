package com.zen.bnc.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_BSA_Product extends Keywords{

	public AO_BSA_Product(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;	
	
	@FindBy(xpath="//p[contains(.,'Cash Deposits')]")
	public WebElement option_CashDeposit;
	
	@FindBy(xpath="//div[2]/div[2]/span[2]/span")
	public WebElement option_acceptortransmitbet;
	
	@FindBy(xpath="//textarea[@data-ng-model='question.proposition.answer']")
	public WebElement txtbx_questionpropositionanswer;	
	
	@FindBy(xpath="//select[@aria-label='Business Account Purpose']")
	public WebElement dd_BusinessAccountPurpose;
	
	
	// for drop-downs
	@FindBy(xpath="//select[@aria-label='Cash Deposits']")
	public WebElement dd_CashDeposits;
	@FindBy(xpath="//select[@aria-label='Cash Withdrawals']")
	public WebElement dd_CashWithdrawals;
	@FindBy(xpath="//select[@aria-label='Domestic Wire Credits']")
	public WebElement dd_DomesticWireCredits;
	@FindBy(xpath="//select[@aria-label='Domestic Wire Debits ']")
	public WebElement dd_DomesticWireDebits;
	@FindBy(xpath="//select[@aria-label='Foreign Wire Credits']")
	public WebElement dd_ForeignWireCredits;
	@FindBy(xpath="//select[@aria-label='Foreign Wire Debits']")
	public WebElement dd_ForeignWireDebits;
	@FindBy(xpath="//select[@aria-label='ACH Credits']")
	public WebElement dd_ACHCredits;
	@FindBy(xpath="//select[@aria-label='ACH Debits']")
	public WebElement dd_ACHDebits;
	@FindBy(xpath="//select[@aria-label='Personal account purpose?']")
	public WebElement dd_Personalaccountpurpose;
	
	// for options
	@FindBy(xpath="//div[2]/div[2]/span/span")
	public List<WebElement> option_CashDeposits;
	
	@FindBy(xpath="//div[3]/div[2]/span/span")
	public List<WebElement> option_CashWithdrawals;
	
	@FindBy(xpath="//div[4]/div[2]/span/span")
	public List<WebElement> option_DomesticWireCredits;
	
	@FindBy(xpath="//div[5]/div[2]/span/span")
	public List<WebElement> option_DomesticWireDebits;
	
	@FindBy(xpath="//div[6]/div[2]/span/span")
	public List<WebElement> option_ForeignWireCredits;
	
	@FindBy(xpath="//div[7]/div[2]/span/span")
	public List<WebElement> option_ForeignWireDebits;
	
	@FindBy(xpath="//div[8]/div[2]/span/span")
	public List<WebElement> option_ACHCredits;
	
	@FindBy(xpath="//div[9]/div[2]/span/span")	
	public List<WebElement> option_ACHCredits2;
	
	@FindBy(xpath="//div[9]/div[2]/span/span")
	public List<WebElement> option_ACHDebits;
	
	@FindBy(xpath="//div[9]/div[2]/span/span")
	public List<WebElement> option_ACHDebits1;
	
	@FindBy(xpath="//div[10]/div[2]/span/span")
	public List<WebElement> option_ACHCredits1;
	
	@FindBy(xpath="//div[11]/div[2]/span/span")	
	public List<WebElement> option_Personalaccountpurpose;
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")	
	public WebElement AO_BSA_Product_title;	
	
	public void verifyPageload_AO_BSA_Product() throws InterruptedException{
		verifyTitle_Content(AO_BSA_Product_title, "BSA");		
	}
	
	public AO_Depositmoney_Product navigate_Depositmoney_Product(String acctBSA) throws InterruptedException{
		handle_weAreSorry();
		String spliter[] = acctBSA.split(",");
		String Personalaccountpurpose = spliter[0];
		String questionpropositionanswer = spliter[1];
		String Depositmoney = spliter[2];
		
		//personal 
		if(isElementVisibile(dd_Personalaccountpurpose)){
			selectDropDownValue(dd_Personalaccountpurpose, Personalaccountpurpose);
			selectOption(option_CashDeposits, Depositmoney);
			selectOption(option_CashWithdrawals, Depositmoney);
			selectOption(option_DomesticWireCredits, Depositmoney);
			selectOption(option_DomesticWireDebits, Depositmoney);
			selectOption(option_ForeignWireCredits, Depositmoney);
			selectOption(option_ForeignWireDebits, Depositmoney);
			selectOption(option_ACHCredits, Depositmoney);
			selectOption(option_ACHDebits, Depositmoney);
			//EnterDataOnTextBox(txtbx_questionpropositionanswer, "CASH");
		}		
		//business
		if(isElementVisibile(dd_BusinessAccountPurpose)){
			isElementVisibile(option_acceptortransmitbet);
			ClickOn(option_acceptortransmitbet);
			selectDropDownValue(dd_BusinessAccountPurpose, 1);
			selectOption(option_CashWithdrawals, Depositmoney);			
			selectOption(option_DomesticWireCredits, Depositmoney);
			selectOption(option_DomesticWireDebits, Depositmoney);
			selectOption(option_ForeignWireCredits, Depositmoney);
			selectOption(option_ForeignWireDebits, Depositmoney);
			selectOption(option_ACHCredits, Depositmoney);			
			selectOption(option_ACHDebits1, Depositmoney);
			selectOption(option_ACHCredits1, Depositmoney);		
		}
			
		if(isElementVisibile(txtbx_questionpropositionanswer)){
			EnterDataOnTextBox(txtbx_questionpropositionanswer, questionpropositionanswer);
		}
			moveScrollToWebElement(button_Continue);	
			clickOnElement(button_Continue);
			test.log(LogStatus.INFO, "Completed navigate_Depositmoney_Product Method Execution");
		
		AO_Depositmoney_Product ao_Depositmoney_Product = new AO_Depositmoney_Product(driver, test);		
		PageFactory.initElements(driver, ao_Depositmoney_Product);
		return ao_Depositmoney_Product;
	}

}
