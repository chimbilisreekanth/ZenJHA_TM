package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.zen.utils.Keywords;

public class AO_LetsGetStarted extends Keywords{
	
	public AO_LetsGetStarted(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//h2[@class='primary1Bold ng-binding']")
	public WebElement AO_LetsGetStarted_title;
	
	@FindBy(xpath="//span[text()='Cancel']")
	public WebElement Link_Cancel;
	
	@FindBy(xpath="//button[@data-ng-if='getStartedCtrl.context.getPropsConfig().newCustomer']")
	public WebElement button_NewApplication;
	
	@FindBy(xpath="//button[@data-ng-if='getStartedCtrl.context.getPropsConfig().continueApplication']")
	public WebElement button_OpenSavedApplication;
	
	
	
	public AO_CompleteAnExistingApplication  ao_CompleteAnExistingApplication() throws InterruptedException {
		ClickOn(button_OpenSavedApplication);	
		
		AO_CompleteAnExistingApplication aO_CompleteAnExistingApplication = new AO_CompleteAnExistingApplication(driver, test);		
		PageFactory.initElements(driver, aO_CompleteAnExistingApplication);
		return aO_CompleteAnExistingApplication;
		
	}
	
	public AO_ProductSelection  ao_productSelection(String appType) throws InterruptedException {
		if (appType.equalsIgnoreCase("new")) {
			ClickOn(button_NewApplication);
		} else {
			ClickOn(button_OpenSavedApplication);
		}
		AO_ProductSelection productSelection = new AO_ProductSelection(driver, test);		
		PageFactory.initElements(driver, productSelection);
		return productSelection;
		
	}
	
	public void verifyPageload_LetsGetStarted() throws InterruptedException{
		verifyTitle_Content(AO_LetsGetStarted_title, "Let's get started!");		
	}
	
	
	
	
	
	
	
	
	

}
