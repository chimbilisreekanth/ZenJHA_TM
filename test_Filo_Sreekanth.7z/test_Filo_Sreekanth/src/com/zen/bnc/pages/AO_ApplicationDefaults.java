package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Constants;
import com.zen.utils.Keywords;

public class AO_ApplicationDefaults extends Keywords{
	public  WebDriverWait wait = new WebDriverWait(this.driver, Constants.globalWait);
	public AO_ApplicationDefaults(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//select[@name='branch']")
	public WebElement dd_Branch;
	
	@FindBy(xpath="//select[@name='originationOfficer']")
	public WebElement PrimaryOfficer;	
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_ApplicationDefaults_title;	
	public void verifyPageload_AO_ApplicationDefaults() throws InterruptedException{
		verifyTitle_Content(AO_ApplicationDefaults_title, "Defaults");		
	}
	
	
	public AO_AccountDefaults navigate_AccountDefaults(String Appdefaults) throws InterruptedException{
		String spliter[] = Appdefaults.split(",");
		String Branch = spliter[0];
		String POfficer = spliter[1];
		
		isElementVisibile(dd_Branch);
		Thread.sleep(2000);
		selectDropDownValue(dd_Branch, Branch);	
		isElementVisibile(PrimaryOfficer);
		selectDropDownValue(PrimaryOfficer, POfficer);		
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_AccountDefaults Method Execution");
		
		AO_AccountDefaults ao_AccountDefaults = new AO_AccountDefaults(driver, test);		
		PageFactory.initElements(driver, ao_AccountDefaults);
		return ao_AccountDefaults;
	}
	
	/*public AO_ApplicationDefaults navigate_ApplicationDefaults(String Branch,String POfficer,String SOfficer) throws InterruptedException{
		isElementVisibile(dd_Branch);
		Thread.sleep(2000);
		selectDropDownValue(dd_Branch, Branch);
		isElementVisibile(PrimaryOfficer);
		selectDropDownValue(PrimaryOfficer, POfficer);
		isElementVisibile(PrimaryOfficer);
		selectDropDownValue(SecondaryOfficer, SOfficer);		
		clickOnElement(button_Continue);
		
		AO_ApplicationDefaults ao_ApplicationDefaults = new AO_ApplicationDefaults(driver, test);		
		PageFactory.initElements(driver, ao_ApplicationDefaults);
		return ao_ApplicationDefaults;
	}*/
}
