package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class SelectLocation extends Keywords{
	
	public SelectLocation(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//select[@name='region']")
	public WebElement dd_region;
	
	@FindBy(xpath="//select[@name='branch']")
	public WebElement dd_branch;
	
	@FindBy(xpath="//button[contains(.,'Continue')]")
	public WebElement btn_Continue;
	
	@FindBy(xpath="//button[contains(.,'Cancel')]")
	public WebElement btn_Cancel;
	
	
	
	
	public HomePage gotoHomePage(String region, String branch) throws InterruptedException{

		if(isElementVisibile(dd_region)){
			moveScrollToWebElement(dd_region);
			selectDropDownValue(dd_region, region);
			if(isElementVisibile(dd_branch)){
				moveScrollToWebElement(dd_branch);
				selectDropDownValue(dd_branch, branch);	
			}
		}
		moveScrollToWebElement(btn_Continue);
		clickOnElement(btn_Continue);
		HomePage homePage = new HomePage(driver, test);
		PageFactory.initElements(driver, homePage);
		
		test.log(LogStatus.INFO, "Completed gotoHomePage method execution");
		return homePage;
	}

}
