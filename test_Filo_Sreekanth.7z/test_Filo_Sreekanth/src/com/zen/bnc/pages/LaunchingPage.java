package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class LaunchingPage extends Keywords{
	
	public LaunchingPage(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	
	public Loginpage gotoLoginpage(String url) throws InterruptedException{
		driver.get(url);
		//driver.navigate().to(Constants.bncURL);
		Loginpage loginpage = new Loginpage(driver, test);
		PageFactory.initElements(driver, loginpage);
		
		test.log(LogStatus.PASS, "loading url - success:--"+url);
		return loginpage;
	}

}
