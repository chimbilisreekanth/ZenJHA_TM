package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_Schoolinformation extends Keywords{

	public AO_Schoolinformation(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_Schoolinformation_title;
		
	@FindBy(xpath="//input[@aria-label=' Occupation']")
	public WebElement Occupation;
	
	@FindBy(xpath="//button[contains(.,'Continue')]")
	public WebElement button_Continue;
	
	@FindBy(xpath="//input[@name='employerName']")
	public WebElement employerName;
	
	@FindBy(xpath="//input[@name='phone']")
	public WebElement phone;
	
	@FindBy(xpath="//select[@name='state']")
	public WebElement state;
	
	@FindBy(xpath="//input[@name='city']")
	public WebElement city;
	
	@FindBy(xpath="//input[@name='zipCode']")
	public WebElement zipCode;
	
	@FindBy(xpath="//input[@name='primary']")
	public WebElement Address;
	
	/*@FindBy(xpath="//h1[@id='WLdialogTitle']")
	public WebElement err_popup;
	@FindBy(xpath="//button[contains(.,'OK')]")
	public WebElement err_Ok_button;*/
	
	public void verifyPageload_AO_BSA() throws InterruptedException{
		verifyTitle_Content(AO_Schoolinformation_title, "School");		
	}	
	
	public AO_BSA navigate_BSA(String occupation,String empName,String Phone,String State,String City,String ZipCode) throws InterruptedException{
		//Thread.sleep(2000);
		handle_weAreSorry();
		if(isElementVisibile(phone)){
			isElementVisibile(phone);
			clearData_Textfield(Occupation);
			EnterDataOnTextBox(Occupation, occupation); //EmployedFT
			clearData_Textfield(employerName);
			EnterDataOnTextBox(employerName, empName); //SSVM
			EnterDataOnTextBox(phone, Phone); //9949225999
			clearData_Textfield(Address);
			EnterDataOnTextBox(Address, City); // ALABAMA
			selectDropDownValue(state, State); //ALABAMA
			EnterDataOnTextBox(city, City); //ALABAMA
			EnterDataOnTextBox(zipCode, ZipCode);  //28262 		
			clickOnElement(button_Continue);
		}		
		test.log(LogStatus.INFO, "Completed navigate_BSA Method Execution");
		
		AO_BSA ao_BSA = new AO_BSA(driver, test);		
		PageFactory.initElements(driver, ao_BSA);		
		return ao_BSA;
	}

}
