package com.zen.bnc.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AddOpportunity extends Keywords{
	
	public String content = "Opportunity created successfully.";
	
	public AddOpportunity(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//button[contains(.,'Create')]")
	public WebElement Create_button;
	
	@FindBy(xpath="//input[@name='productName']")
	public WebElement productName;
	
	@FindBy(xpath="//div[text()='Individual']")
	public WebElement ProductCategories;
	//
	@FindBy(xpath="//li[@class='arrow ng-scope']")
	public List<WebElement> CategoriesList;
	
	
	@FindBy(xpath="//div[text()='Checking']")
	public WebElement Product;
	//
	@FindBy(xpath="//li[@class='arrow ng-scope']")
	public List<WebElement> ProductList;
	
	//
	@FindBy(xpath="//li[@class='roundedAdd ng-scope']")
	public List<WebElement> GroupList;
	
	
	@FindBy(xpath="//button[@data-ng-click='addProducts()']")
	public WebElement Product_DoneButton;
	
	@FindBy(xpath="//input[@name='assignee']")
	public WebElement AssignedTo;
	
	@FindBy(xpath="//select[@name='selectRegion']")
	public WebElement selectRegion;
	
	@FindBy(xpath="//select[@placeholder='Select Branch']")
	public WebElement SelectBranch;
	
	@FindBy(xpath="//div[text()='Branch Manager']")
	public WebElement SelectAssignee;
	
	@FindBy(xpath="//div[text()='Zenmonics JXCHG Tester']")
	public WebElement SelectAssignee1;
	//
	@FindBy(xpath="//div[@class='ui-grid-cell-contents ng-binding ng-scope']")
	public List<WebElement> Assignee;
	
	@FindBy(xpath="//button[@data-ng-click='applyAssignOpportunityModal()']")
	public WebElement Assign_Button;
	
	@FindBy(xpath="//textarea[@name='comments']")
	public WebElement comments;
	
	@FindBy(xpath="//select[@name='leadSource']")
	public WebElement leadSource;
	
	@FindBy(xpath="//select[@name='stage']")
	public WebElement stage;
	
	@FindBy(xpath="//select[@name='followupType']")
	public WebElement followupType;
	
	@FindBy(xpath="//select[@name='status']")
	public WebElement status;
	
	@FindBy(xpath="//button[@data-ng-click='createOpportunity()']")
	public WebElement createOpportunity_button;
	
	@FindBy(xpath="//div[@class='flexCenter']")
	public WebElement createOpportunity_success_message;
	
	@FindBy(xpath="//button[@class='primaryActionButton']")
	public WebElement createOpportunity_Done;
	
	@FindBy(xpath="//select[@name='lostReason']")
	public WebElement lostReason;
	
	@FindBy(xpath="//div[text()='Please select Lost Reason']")
	public WebElement error_lostReason;
	
	
	// calenders
	@FindBy(xpath="//span[@ng-click='needeByDateOpen=!needeByDateOpen']")
	public WebElement neededBYDate;
	
	@FindBy(xpath="//span[@ng-click='creationDateOpen=!creationDateOpen']")
	public WebElement creationDate;
	
	@FindBy(xpath="//span[@ng-click='effDateOpen=!effDateOpen']")
	public WebElement effectiveDate;
	
	public void selectOMneededBYDate(String ndate) throws InterruptedException{
		clickOnElement(neededBYDate);
		datePickernew(ndate);
	}
	
	public void selectOMcreateBYDate(String crdate) throws InterruptedException{
		clickOnElement(creationDate);
		datePickernew(crdate);
	}
	
	public void selectOMeffectiveDate(String cdate) throws InterruptedException{
		clickOnElement(effectiveDate);
		datePickernew(cdate);
	}
	
	//errors
	@FindBy(xpath="//h1[text()='We�re Sorry...']")
	public WebElement error_stage;
	@FindBy(xpath="//button[text()='OK']")
	public WebElement error_stage_OK;
	
	
	
	/*public OpportunityManagement addingOpportunity() throws InterruptedException{
		//AddCustomerName();
		AddProduct();
		AssignedTo();
		AddOpportunity_reminingData();
		createOpportunity_complete();
		takeScreenShot();
		OpportunityManagement opportunityManagement = new OpportunityManagement(driver, test);
		PageFactory.initElements(driver, opportunityManagement);
		return opportunityManagement;
	}
*/
	
	public void AddProduct(String categoriesList, String productList, String groupList) throws InterruptedException{
		isElementVisibile(productName);
		ClickOnIcon(productName);
		isElementVisibile(ProductCategories);
		selectOption(CategoriesList, categoriesList);
		//clickOnElement(ProductCategories);
		isElementVisibile(Product);
		selectOption(ProductList, productList);
		//clickOnElement(Product);	
		selectOption(GroupList, groupList);
		//clickOnElement(ProductGroup);
		takeScreenShot();
		Thread.sleep(2000);
		ClickOn(Product_DoneButton);		
	}
	
	public void AssignedTo(String SelectRegion, String productList, String groupList) throws InterruptedException{
		moveScrollToWebElement(AssignedTo);
		isElementVisibile(AssignedTo);
		ClickOnIcon(AssignedTo);
		isElementVisibile(selectRegion);
		moveScrollToWebElement(selectRegion);
		selectDropDownValue(selectRegion,SelectRegion);
		moveScrollToWebElement(Assign_Button);
		selectDropDownValue(SelectBranch,productList);
		Thread.sleep(2000);
		selectOption(Assignee, groupList);
		moveScrollToWebElement(Assign_Button);
		Thread.sleep(2000);
		ClickOn(Assign_Button);
	}
	
	public void AddOpportunity_reminingData(String Comments,String LeadSource,String Stage,String FollowupType,String Status,String LostReason,String neededBYDate,String effectiveDate,String creationDateOpen) throws InterruptedException{
		isElementClickable(comments);
		EnterDataOnTextBox(comments, Comments);
				
		selectDropDownValue(leadSource, LeadSource);
		selectDropDownValue(stage, Stage);
		
		//Stage validation
		if (Stage.equalsIgnoreCase("Closed")){
			Assert.assertTrue(error_stage.isDisplayed());
			error_stage_OK.click();
			selectDropDownValue(stage, Comments);
			test.log(LogStatus.PASS, "Getting error message 'Please select Lost Reason' while submitting without lost reason");
		}
		Thread.sleep(2000);
		selectDropDownValue(followupType, FollowupType);
		selectDropDownValue(status, Status);
		//Status validation
		if (Status.equalsIgnoreCase("Lost")){
			ClickOn(createOpportunity_button);
			isElementVisibile(error_lostReason);
			Assert.assertTrue(error_lostReason.isDisplayed());
			test.log(LogStatus.PASS, "Getting error message aftering selecting Status = Closed");
			selectDropDownValue(lostReason, LostReason);
		}
		selectOMneededBYDate(neededBYDate);
		selectOMeffectiveDate(effectiveDate);
		selectOMcreateBYDate(creationDateOpen);
		//selectOMcreateBYDate(creationDateOpen);
		
		takeScreenShot();
		ClickOn(createOpportunity_button);
		
		try {
			//NeededByDate validation
			if (error_stage.isDisplayed()){
				Assert.assertTrue(error_stage.isDisplayed());
				test.log(LogStatus.INFO, "NeededByDate - Validation popup has been displayed");
				error_stage_OK.click();
				selectOMneededBYDate(Comments);
				test.log(LogStatus.PASS, "Getting error message while selecting 'NeededByDate' <= todays date");
				ClickOn(createOpportunity_button);
				}
		} catch (Exception e) {
			
	}
		
}
	
	public void createOpportunity_complete() throws InterruptedException{
		isElementClickable(createOpportunity_success_message);
		verifyTitle_Content(createOpportunity_success_message, this.content);
		takeScreenShot();
		ClickOn(createOpportunity_Done);			
	}	

}
