package com.zen.bnc.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_Depositmoney_Product extends Keywords{

	public AO_Depositmoney_Product(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//span[contains(.,'Back')]")
	public WebElement button_Back;
	
	@FindBy(xpath="//div[@class='secondaryBlockButton accentColor1 ng-scope']")
	public List<WebElement> options_Depositmoney;
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_Depositmoney_Product_title;	
	public void verifyPageload_AO_Depositmoney_Product() throws InterruptedException{
		verifyTitle_Content(AO_Depositmoney_Product_title, "Deposit money");		
	}
	
	public AO_Depositmoney navigate_AO_Depositmoney(String AO_Depositmoney) throws InterruptedException{
		isElementVisibile(button_Back);
		selectOption(options_Depositmoney, AO_Depositmoney);
		
		//clickOnElement(button_Back);
		test.log(LogStatus.INFO, "Completed navigate_AO_Depositmoney Method Execution");
		
		AO_Depositmoney ao_Depositmoney = new AO_Depositmoney(driver, test);		
		PageFactory.initElements(driver, ao_Depositmoney);
		return ao_Depositmoney;
	}
	
	/*public AO_Depositmoney navigate_AO_Depositmoney(String AO_Depositmoney) throws InterruptedException{
		isElementVisibile(button_Back);
		selectOption(options_Depositmoney, AO_Depositmoney);
		
		//clickOnElement(button_Back);
		
		AO_Depositmoney ao_Depositmoney = new AO_Depositmoney(driver, test);		
		PageFactory.initElements(driver, ao_Depositmoney);
		return ao_Depositmoney;
	}*/


}
