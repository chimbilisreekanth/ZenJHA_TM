package com.zen.bnc.pages;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Constants;
import com.zen.utils.Keywords;

public class Menus extends Keywords{
	
	public  WebDriverWait wait = new WebDriverWait(this.driver, Constants.globalWait);
	
	public Menus(WebDriver driver, ExtentTest test) {
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//a[contains(.,' Open Account ')]")
	public WebElement button_AO;
	
	@FindBy(xpath="//button[contains(.,'Complete Your Profile')]")
	public WebElement Cust_CompleteYourProfile_button;

	@FindBy(xpath="//span[@class='icon']")
	public WebElement menuIcon;
	
	@FindBy(xpath="//a[@data-ng-click='closeModal()']")
	public WebElement Search_close;
	
	@FindBy(xpath="//span[@class='ng-binding ng-scope']")
	public List<WebElement> Menus;
	
	@FindBy(xpath="//a[@class='ng-binding']")
	public List<WebElement>	MenuItems;
	
	@FindBy(xpath="//span[contains(.,'Sales')]")
	public WebElement menu_Sales;
	
	@FindBy(xpath="//a[contains(.,' Open Account ')]")
	public WebElement menuoption_OpenAccount;
	
	@FindBy(xpath="//a[contains(.,' Knowledge Center ')]")
	public WebElement menuoption_KnowledgeCenter;
	
	@FindBy(xpath="//button[contains(.,'Leave')]")
	public WebElement confirmPopup_Leave;
	
	
	
	public void gotoModule(String menu, String menuItem) throws InterruptedException{
		wait.until(ExpectedConditions.visibilityOf(menuIcon));
		ClickOnIcon(menuIcon);
		Thread.sleep(3000);
		List<WebElement> menus = Menus;
		List<WebElement> menuItems = MenuItems;
		
		if(isElementVisibile(menuoption_OpenAccount)){
			ClickOnIcon(menuoption_KnowledgeCenter);
			wait.until(ExpectedConditions.visibilityOf(confirmPopup_Leave));
			ClickOnIcon(confirmPopup_Leave);			
			ClickOnIcon(menuIcon);
			ClickOnIcon(menuoption_OpenAccount);
		}
		
		boolean broken = false;
		for(WebElement MenusList : menus){
			if(MenusList.getText().equalsIgnoreCase(menu)){ 
				wait.until(ExpectedConditions.visibilityOf(MenusList)); 
				moveScrollToWebElement(MenusList);				
				MenusList.click();
				Thread.sleep(2000);
			}
				for(WebElement menuItemsList : menuItems){
					if(menuItemsList.getText().equalsIgnoreCase(menuItem)) {
                        wait.until(ExpectedConditions.visibilityOf(menuItemsList));
                        clickOnElement(menuItemsList);
						//menuItemsList.click();
						test.log(LogStatus.INFO, "Selected Menu:--"+menu+"Selected Menu-Item:"+menuItem);
						broken = true;
						break;
					}
				}
				if(broken){
					break;
				}
		}
	}
	
	public void gotoModule(HashMap<String, String> data) throws InterruptedException{
		/*String spliter[] = data.get("info-LB").split(",");*/
		String menu = data.get("Menu");
		String menuItem = data.get("MenuItem");
		wait.until(ExpectedConditions.visibilityOf(menuIcon));
		ClickOnIcon(menuIcon);
		Thread.sleep(3000);
		List<WebElement> menus = Menus;
		List<WebElement> menuItems = MenuItems;
		
		if(isElementVisibile(menuoption_OpenAccount)){
			ClickOnIcon(menuoption_KnowledgeCenter);
			wait.until(ExpectedConditions.visibilityOf(confirmPopup_Leave));
			ClickOnIcon(confirmPopup_Leave);			
			ClickOnIcon(menuIcon);
			ClickOnIcon(menuoption_OpenAccount);
		}
		
		boolean broken = false;
		for(WebElement MenusList : menus){
			if(MenusList.getText().equalsIgnoreCase(menu)){ 
				wait.until(ExpectedConditions.visibilityOf(MenusList)); 
				moveScrollToWebElement(MenusList);				
				MenusList.click();
				Thread.sleep(2000);
			}
				for(WebElement menuItemsList : menuItems){
					if(menuItemsList.getText().equalsIgnoreCase(menuItem)) {
                        wait.until(ExpectedConditions.visibilityOf(menuItemsList));
                        clickOnElement(menuItemsList);
						//menuItemsList.click();
						test.log(LogStatus.INFO, "Selected Menu:--"+menu+"Selected Menu-Item:"+menuItem);
						broken = true;
						break;
					}
				}
				if(broken){
					break;
				}
		}
	}
	
	public Manage_Opportunities selectMenuItem(String menu, String menuItem) throws InterruptedException{
		isElementVisibile(Cust_CompleteYourProfile_button);
		moveScrollToWebElement(Cust_CompleteYourProfile_button);
		//isElementClickable(Cust_CompleteYourProfile_button);
		moveScrollToWebElement(menuIcon);
		ClickOnIcon(menuIcon);
		//isElementVisibile(menuIcon);
		driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
        wait.until(ExpectedConditions.visibilityOf(menuIcon)); 
		Thread.sleep(2000);
		List<WebElement> menus = Menus;
		List<WebElement> menuItems = MenuItems;
		
		boolean broken = false;
		for(WebElement MenusList : menus){
			if(MenusList.getText().equalsIgnoreCase(menu)){ 
				moveScrollToWebElement(MenusList);
				//isElementVisibile(MenusList);
				//driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
                //     WebDriverWait wait = new WebDriverWait(this.driver, 1000);
                wait.until(ExpectedConditions.visibilityOf(MenusList)); 
				MenusList.click();
				//Thread.sleep(2000);
			}
				for(WebElement menuItemsList : menuItems){
					if(menuItemsList.getText().equalsIgnoreCase(menuItem)) {
						//isElementVisibile(menuItemsList);
						//driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
                        //     WebDriverWait wait = new WebDriverWait(this.driver, 1000);
                        wait.until(ExpectedConditions.visibilityOf(menuItemsList)); 
						menuItemsList.click();
						test.log(LogStatus.INFO, "Selected Menu:--"+menu+"Selected Menu-Item:"+menuItem);
						broken = true;
						break;
					}
				}
				if(broken){
					break;
				}
			}
		
		isElementClickable(Search_close);
		ClickOnIcon(Search_close);
		
		Manage_Opportunities manage_Opportunities = new Manage_Opportunities(driver, test);		
		PageFactory.initElements(driver, manage_Opportunities);
		test.log(LogStatus.INFO, "Manage_Opportunities page loaded -- success");
		return manage_Opportunities;				 
		}
	}

