package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_Alittlebitabout extends Keywords{

	public AO_Alittlebitabout(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickBack()']")
	public WebElement button_back;
	
	@FindBy(xpath="//button[@name='lastName']")
	public WebElement lastName;
	
	@FindBy(xpath="//select[@name='gender']")
	public WebElement gender;
	
	@FindBy(xpath="//select[@aria-label='Business Class Type']")
	public WebElement dd_BusinessClassType;
	
	@FindBy(xpath="//select[@name='naicsCategory']")
	public WebElement dd_naicsCategory;
	
	@FindBy(xpath="//select[@name='naicsCode']")
	public WebElement naicsCode;
	@FindBy(xpath="//select[@name='phoneType']")
	public WebElement dd_phoneType;
	
	@FindBy(xpath="//input[@aria-label='Phone']")
	public WebElement Phone;
	
	@FindBy(xpath="//input[@aria-label='Email Address']")
	public WebElement EmailAddress;
	
	@FindBy(xpath="//select[@name='citizenship']")
	public WebElement dd_citizenship;
	
	@FindBy(xpath="//input[@name='orgName']")
	public WebElement txtbx_orgName;
	
	@FindBy(xpath="//input[@name='orgName'][@disabled='disabled']")
	public WebElement txtbx_orgNamedisabled;	
	
	@FindBy(xpath="//input[@name='firstName']")
	public WebElement txtbx_firstName;
	@FindBy(xpath="//input[@name='firstName'][@disabled='disabled']")
	public WebElement txtbx_firstNamedisabled;
	
	@FindBy(xpath="//input[@name='middleName']")
	public WebElement txtbx_middleName;
	@FindBy(xpath="//input[@name='lastName']")
	public WebElement txtbx_lastName;
	@FindBy(xpath="//input[@name='suffix']")
	public WebElement txtbx_suffix;	
	
	public AO_Alittlebitmoreabout navigate_Alittlebitmoreabout(String infoAlittlebitmoreabout) throws InterruptedException{
		String spliter[] = infoAlittlebitmoreabout.split(",");
		String Gender = spliter[0];
		String phoneType = spliter[1];
		String BusinessClassType = spliter[2];
		String naicsCategory = spliter[3];
		String naicCode = spliter[4];
		String phno = spliter[5];
		String emailID = spliter[6];
		String phoneTyp = spliter[7];
		String citizenship = spliter[8];
		String fName = spliter[9];
		String mName = spliter[10];
		String lName = spliter[11];
		String suffix = spliter[12];
		
		handle_weAreSorry();
		if(isElementVisibile(dd_BusinessClassType)){
			if(!isElementVisibile(txtbx_orgNamedisabled)){
				EnterDataOnTextBox(txtbx_orgName, fName);
			}
			EnterDataOnTextBox(EmailAddress, emailID);
			selectDropDownValue(dd_phoneType, phoneTyp);
			EnterDataOnTextBox(Phone, phno);
			selectDropDownValue(dd_BusinessClassType, BusinessClassType);
			selectDropDownValue(dd_naicsCategory, naicsCategory);			
			Thread.sleep(2000);
			selectDropDownValue(naicsCode, naicCode);
		}
		
		if(isElementVisibile(txtbx_firstName)){
			if(!isElementVisibile(txtbx_firstNamedisabled)){
				EnterDataOnTextBox(txtbx_firstName, fName);
				EnterDataOnTextBox(txtbx_middleName, mName);
				EnterDataOnTextBox(txtbx_lastName, lName);
				EnterDataOnTextBox(txtbx_suffix, suffix);
			}			
		}
		
		if(isElementVisibile(gender)){		
		selectDropDownValue(gender, Gender);
		EnterDataOnTextBox(EmailAddress, emailID);
		selectDropDownValue(dd_phoneType, phoneType);
		EnterDataOnTextBox(Phone, phno);
		selectDropDownValue(dd_citizenship, citizenship);
		}
		moveScrollToWebElement(button_Continue);
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_Alittlebitmoreabout Method Execution");
		
		AO_Alittlebitmoreabout ao_Alittlebitmoreabout = new AO_Alittlebitmoreabout(driver, test);		
		PageFactory.initElements(driver, ao_Alittlebitmoreabout);
		return ao_Alittlebitmoreabout;
	}


}
