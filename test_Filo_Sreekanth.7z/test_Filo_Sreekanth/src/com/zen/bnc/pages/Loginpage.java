package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class Loginpage extends Keywords{
	
	private WebDriver driver;
    private ExtentTest test;
	
	public Loginpage(WebDriver driver, ExtentTest test){
		super(driver, test);
		//PageFactory.initElements(new Loginpage(driver,test), this);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//*[@id='appmod']")
	public WebElement Isdemo_Checkbox;
	
	@FindBy(xpath="//input[@name='username']")
	public WebElement userName;
	
	@FindBy(xpath="//input[@name='passwd']")
	public WebElement password;
	
	@FindBy(xpath="//button[@type='submit']")
	public WebElement submit_button;
	
	
	public Object doLogin(String uname, String pwd) throws InterruptedException{
		
		EnterDataOnTextBox(userName, uname);
		EnterDataOnTextBox(password, pwd);
		ClickOn(submit_button);
		
		boolean loginsuccess = true;
		if(loginsuccess){
			//return PageFactory.initElements(driver, RolePage.class);
			RolePage rolePage = new RolePage(driver, test);		
			PageFactory.initElements(driver, rolePage);		
			return rolePage;
		}else {
		//return PageFactory.initElements(driver, Loginpage.class);
			Loginpage loginpage = new Loginpage(driver, test);		
			PageFactory.initElements(driver, loginpage);
			test.log(LogStatus.PASS, "Loginpage loaded - success");
			return loginpage;
		}
	}
	
	/*public RolePage verifyTittle(String expTittle){
		
	}*/
	

}
