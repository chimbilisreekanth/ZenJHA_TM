package com.zen.bnc.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_Certificateproductdetails extends Keywords{
	
	public String content = "Opportunity created successfully.";
	
	public AO_Certificateproductdetails(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//input[contains(@name,'foundAmountCertDep')]")
	public WebElement txtbx_foundAmountCertDep;
	
	@FindBy(xpath="//input[@aria-label='Interest Rate']")
	public WebElement txtbx_InterestRate;
	
	@FindBy(xpath="//input[@aria-label='Interest term']")
	public WebElement txtbx_Interestterm;
	
	@FindBy(xpath="//label[@class='ng-binding']")
	public List<WebElement> options_PaymeBy;
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;
	
	public AO_Depositmoney_Product navigateTo_AO_Depositmoney_Product(String CDInfo) throws InterruptedException {
		String spliter[] = CDInfo.split(",");
		String foundAmountCertDep = spliter[0];
		String InterestRate = spliter[1];
		String Interestterm = spliter[2];
		String PaymeBy = spliter[3];
		handle_weAreSorry();
	if (isElementVisibile(txtbx_foundAmountCertDep)){
		EnterDataOnTextBox(txtbx_InterestRate, InterestRate);
		EnterDataOnTextBox(txtbx_foundAmountCertDep, foundAmountCertDep);		
		isElementVisibile(txtbx_Interestterm);
		EnterDataOnTextBox(txtbx_Interestterm, Interestterm);
		selectOption(options_PaymeBy, PaymeBy);
		moveScrollToWebElement(button_Continue);
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigateTo_AO_Depositmoney_Product Method Execution");
		}
	AO_Depositmoney_Product ao_Depositmoney_Product = new AO_Depositmoney_Product(driver, test);		
	PageFactory.initElements(driver, ao_Depositmoney_Product);		
	return ao_Depositmoney_Product;
	
	}	

}
