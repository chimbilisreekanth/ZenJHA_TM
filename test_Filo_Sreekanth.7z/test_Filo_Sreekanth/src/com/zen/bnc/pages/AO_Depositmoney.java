package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_Depositmoney extends Keywords{

	public AO_Depositmoney(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//button[@class='primaryActionButton  ng-binding ng-scope']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//input[@data-label='Funding Amount']")
	public WebElement Amount;
	
	@FindBy(xpath="//input[@aria-label='Funding Amount']")
	public WebElement fundingAmount;
	
	@FindBy(xpath="//input[@aria-label='Number on Card']")
	public WebElement numberonCard;
	
	@FindBy(xpath="//input[@aria-label='Expiration Date']")
	public WebElement expirationDate;
	
	@FindBy(xpath="//input[@aria-label='CVV']")
	public WebElement cvv;
	
	@FindBy(xpath="//select[@aria-label='Contribution Type']")
	public WebElement dd_ContributionType;
	
	@FindBy(xpath="//input[@disabled='disabled']")
	public WebElement amount_disabled;
	
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_Depositmoney_title;	
	public void verifyPageload_AO_Depositmoney() throws InterruptedException{
		verifyTitle_Content(AO_Depositmoney_title, "Deposit money");		
	}
	
	public AO_Services navigate_Services(String Samunt) throws InterruptedException{
		String spliter[] = Samunt.split(",");
		String saperator = spliter[0];	
		String amount = spliter[1];
		String noonCard = spliter[2];
		String expDate = spliter[3];
		String cvvno = spliter[4];
		String ContributionType = spliter[5];
		handle_weAreSorry();
		
		// for non CD/IRA accounts
		if(isElementVisibile(Amount)){
			if(!isElementVisibile(amount_disabled)){
			EnterDataOnTextBox(Amount, amount);	
			}
		}		
		if(isElementVisibile(numberonCard)){
			// for non CD/IRA accounts
			if(!isElementVisibile(amount_disabled)){
				EnterDataOnTextBox(fundingAmount, amount);	
			}
			EnterDataOnTextBox(numberonCard, noonCard);
			EnterDataOnTextBox(expirationDate, expDate);
			EnterDataOnTextBox(cvv, cvvno);
			
			if(isElementVisibile(dd_ContributionType)){
				selectDropDownValue(dd_ContributionType, ContributionType);
			}
		}		
		
		
		moveScrollToWebElement(button_Continue);
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_Services Method Execution");
		
		AO_Services ao_Services = new AO_Services(driver, test);		
		PageFactory.initElements(driver, ao_Services);
		return ao_Services;
	}
	
	public AO_Depositmoney_Product navigate_Depositmoney_Product2(String SAmount) throws InterruptedException{
		String spliter[] = SAmount.split(",");
		//String year = spliter[2];
		String amount = spliter[1];
		String saperator = spliter[0];
		
		handle_weAreSorry();
		EnterDataOnTextBox(Amount, amount);
		clickOnElement(button_Continue);
		
		AO_Depositmoney_Product ao_Depositmoney_Product = new AO_Depositmoney_Product(driver, test);		
		PageFactory.initElements(driver, ao_Depositmoney_Product);
		return ao_Depositmoney_Product;
	}
	
	public AO_Services navigate_Depositmoney_Product(String SAmount) throws InterruptedException{
		String spliter[] = SAmount.split(",");
		//String year = spliter[2];
		String amount = spliter[1];
		String saperator = spliter[0];
		
		Thread.sleep(2000);
		isElementVisibile(Amount);
		isElementVisibile(button_Continue);
		EnterDataOnTextBox(Amount, amount);
		clickOnElement(button_Continue);
		
		AO_Services ao_Services = new AO_Services(driver, test);		
		PageFactory.initElements(driver, ao_Services);
		return ao_Services;
	}


}
