package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class HomePage extends Keywords{	
	
	public HomePage(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//span[contains(.,'Reminders')]")
	public WebElement Dashboard_Reminders;
	
	
	@FindBy(xpath="//span[@class='ng-scope'][text()='Customer Search']")
	public WebElement CustomerSearch;
	

	@FindBy(xpath="//*[@name='custNbr']")
	public WebElement CustomerNumber_Textbox;
	
	@FindBy(xpath="//button[@data-ng-click='doPartySearch()']")
	public WebElement SearchforCustomer_button;
	
	@FindBy(xpath="//span[text()='Logout']")
	public WebElement Logout;
	

	public HomePage  loadcustomer(String custNo) throws InterruptedException {
		//Thread.sleep(8000);
		moveScrollToWebElement(Dashboard_Reminders);
		isElementClickable(Dashboard_Reminders);
		moveScrollToWebElement(CustomerSearch);
		isElementClickable(CustomerSearch);
		ClickOn(CustomerSearch);
		isElementClickable(CustomerNumber_Textbox);
		//ClickOn(CustomerNumber_Textbox);
		EnterDataOnTextBox(CustomerNumber_Textbox, custNo);
		ClickOn(SearchforCustomer_button);
		test.log(LogStatus.INFO, "loading customer - success");
		
		HomePage homePage = new HomePage(driver, test);		
		PageFactory.initElements(driver, homePage);
		return homePage;
	}
	
	
	
}
