package com.zen.bnc.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_Services extends Keywords{

	public AO_Services(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//button[@class='primaryActionButton  ng-binding ng-scope']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//label[@class='dashed-border-bottom ng-binding']")
	public List<WebElement> options_services;
	
	@FindBy(xpath="//span[contains(.,'Optional')]")
	public WebElement Optional_Services;
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_Services_title;	
	public void verifyPageload_AO_Services() throws InterruptedException{
		verifyTitle_Content(AO_Services_title, "Services");		
	}
	
	public AO_Disclosures navigate_Disclosures() throws InterruptedException{
		Thread.sleep(2000);
		isElementVisibile(Optional_Services);		
		//selectCheckbox(options_services, "BNC ATM/Debit Card");
		//selectCheckbox(options_services, "Automatic Funds Transfer");
		moveScrollToWebElement(button_Continue);
		clickOnElement(button_Continue);		
		test.log(LogStatus.INFO, "Completed navigate_Disclosures Method Execution");
		
		AO_Disclosures ao_Disclosures = new AO_Disclosures(driver, test);		
		PageFactory.initElements(driver, ao_Disclosures);
		return ao_Disclosures;
	}


}
