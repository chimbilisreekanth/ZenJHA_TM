package com.zen.bnc.pages;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Constants;
import com.zen.utils.Keywords;

public class AO_finalPage extends Keywords{
	String applicationNumber = null;
	String accountnumber = null;
	
	public AO_finalPage(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickDone()']")
	public WebElement button_Done;
	
	@FindBy(xpath="//span[contains(.,'Applicant Name:')]")
	public WebElement text_ApplicantName;
	
	@FindBy(xpath="//span[contains(.,'Application Number:')]")
	public WebElement option_ApplicationNumber;
	@FindBy(xpath="//table/tbody/tr[2]/td[3]")
	public WebElement ApplicationNumber;
	
	@FindBy(xpath="//span[contains(.,'Account number:')]")
	public WebElement option_Accountnumber;
	@FindBy(xpath="//table/tbody/tr[3]/td[3]")
	public WebElement Accountnumber;
	
	
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_finalPage_title;	
	
	public void verifyPageload_AO_finalPage() throws InterruptedException{
		verifyTitle_Content(AO_finalPage_title, "Congratulations");	
	}
	
	public void Ao_complete() throws InterruptedException{
		Exists(option_ApplicationNumber);
				
		if(isElementVisibile(option_ApplicationNumber)){
		applicationNumber = getText(ApplicationNumber);
		test.log(LogStatus.FAIL, "ApplicationNumber:--"+applicationNumber);
		}
		if(isElementVisibile(option_Accountnumber)){
		accountnumber = getText(Accountnumber);
		test.log(LogStatus.PASS, "Accountnumber:--"+accountnumber);
		}
		moveScrollToWebElement(button_Done);
		ClickOn(button_Done);
		test.log(LogStatus.INFO, "Completed Ao_complete Method Execution");
	}
	
	public String result() throws IOException{
		if(applicationNumber != null)
			return applicationNumber;
		else
			return accountnumber;
	}
	
	public String resultStatus(){
		if(applicationNumber != null)
			return Constants.KEYWORD_FAIL;
		else
			return Constants.KEYWORD_PASS;
	}
	
}
