package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_Disclosures extends Keywords{

	public AO_Disclosures(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//button[@class='primaryActionButton  ng-binding ng-scope']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//span[contains(.,'Please read and consent to the following conditions')]")
	public WebElement text_Disclosures;
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_Disclosures_title;	
	public void verifyPageload_AO_Disclosures() throws InterruptedException{
		verifyTitle_Content(AO_Disclosures_title, "Disclosures");		
	}
		
	public AO_finalPage navigate_finalPage() throws InterruptedException{
		handle_weAreSorry();
		//isElementVisibile(text_Disclosures);
		moveScrollToWebElement(button_Continue);
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_finalPage Method Execution");
		
		AO_finalPage ao_finalPage = new AO_finalPage(driver, test);		
		PageFactory.initElements(driver, ao_finalPage);
		return ao_finalPage;
	}


}
