package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_information extends Keywords{

	public AO_information(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_information_title;	
	
	@FindBy(xpath="//button[contains(.,'Confirm')]")
	public WebElement BUTTON_Confirm;
	
	
	public void verifyPageload_AO_information() throws InterruptedException{
		verifyTitle_Content(AO_information_title, "Application Defaults");		
	}	
	
	public AO_ApplicationDefaults navigate_ApplicationDefaults () throws InterruptedException{
		isElementVisibile(button_Continue);		
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_ApplicationDefaults Method Execution");
		
		AO_ApplicationDefaults ao_ApplicationDefaults = new AO_ApplicationDefaults(driver, test);		
		PageFactory.initElements(driver, ao_ApplicationDefaults);
		return ao_ApplicationDefaults;
	}
	
	public AO_BSA navigate_bsa() throws InterruptedException{
		moveScrollToWebElement(BUTTON_Confirm);		
		clickOnElement(BUTTON_Confirm);
		test.log(LogStatus.INFO, "Completed navigate_bsa Method Execution");
		
		AO_BSA ao_bsa = new AO_BSA(driver, test);		
		PageFactory.initElements(driver, ao_bsa);
		return ao_bsa;
	}
	


}
