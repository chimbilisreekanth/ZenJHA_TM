package com.zen.bnc.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_Pod extends Keywords{

	public AO_Pod(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//input[@name='firstName']")
	public WebElement txtbx_firstName;
	@FindBy(xpath="//input[@name='firstName'][@disabled='disabled']")
	public WebElement txtbx_firstNamedisabled;
	@FindBy(xpath="//input[@name='middleName']")
	public WebElement txtbx_middleName;
	@FindBy(xpath="//input[@name='lastName']")
	public WebElement txtbx_lastName;
	@FindBy(xpath="//input[@name='suffix']")
	public WebElement txtbx_suffix;
	
	@FindBy(xpath="//input[@name='ssn']")
	public WebElement txtbx_ssn;
	@FindBy(xpath="//input[@name='email']")
	public WebElement txtbx_email;
	@FindBy(xpath="//input[@name='phone']")
	public WebElement txtbx_phone;
	@FindBy(xpath="//input[@name='dob']")
	public WebElement txtbx_dob;
	@FindBy(xpath="//input[@name='primary']")
	public WebElement txtbx_primary;
	@FindBy(xpath="//input[@name='city']")
	public WebElement txtbx_city;
	@FindBy(xpath="//select[@name='state']")
	public WebElement txtbx_state;
	@FindBy(xpath="//input[@name='zipCode']")
	public WebElement txtbx_zipCode;
	
	@FindBy(xpath="//form/div[9]/div/span/span")
	public List<WebElement> options_WilladdressbethesameasthePrimaryOwner;
	
	
	
	
	public AO_ApplicationDefaults navigate_AO_ApplicationDefaults(String pod) throws InterruptedException{
		handle_weAreSorry();
		String spliter[] = pod.split(",");
		String firstName = spliter[0];
		String middleName = spliter[1];
		String lastName = spliter[2];
		String suffix = spliter[3];
		String ssn = spliter[4];
		String email = spliter[5];
		String phone = spliter[6];
		String primary = spliter[7];
		String city = spliter[8];
		String state = spliter[9];
		String zipCode = spliter[10];
		String WilladdressbethesameasthePrimaryOwner = spliter[11];
		
		if(!isElementVisibile(txtbx_firstNamedisabled)){
			EnterDataOnTextBox(txtbx_firstName, firstName);
			EnterDataOnTextBox(txtbx_middleName, middleName);
			EnterDataOnTextBox(txtbx_lastName, lastName);
			EnterDataOnTextBox(txtbx_suffix, suffix);
		}
		
		EnterDataOnTextBox(txtbx_ssn, ssn);
		
		EnterDataOnTextBox(txtbx_email, email);
		
		EnterDataOnTextBox(txtbx_phone, phone);
		
		EnterDataOnTextBox(txtbx_dob, getCustomDatePast(10, "Y"));
		
		selectOption(options_WilladdressbethesameasthePrimaryOwner, WilladdressbethesameasthePrimaryOwner);
		if(WilladdressbethesameasthePrimaryOwner.equalsIgnoreCase("NO")){			
			EnterDataOnTextBox(txtbx_primary, primary);
			
			EnterDataOnTextBox(txtbx_city, city);
			
			selectDropDownValue(txtbx_state, state);
			
			EnterDataOnTextBox(txtbx_zipCode, zipCode);
		}
		
		moveScrollToWebElement(button_Continue);
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_AO_BSA_Product Method Execution");
		
		AO_ApplicationDefaults ao_ApplicationDefaults = new AO_ApplicationDefaults(driver, test);		
		PageFactory.initElements(driver, ao_ApplicationDefaults);
		return ao_ApplicationDefaults;
	}
	
//	public void verifyPageload_LetsGetStarted(){
//		verifyTitle_Content(AO_LetsGetStarted_title, "Let's get started!");
//		
//	}

}
