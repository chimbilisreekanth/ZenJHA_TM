package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.zen.utils.Keywords;

public class AO_CompleteAnExistingApplication extends Keywords{
	
	public AO_CompleteAnExistingApplication(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//h2[@class='primary1Bold ng-binding']")
	public WebElement AO_CompleteAnExistingApplication_title;
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickCancel()']")
	public WebElement button_Cancel;
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_SearchApplication;
	
	@FindBy(xpath="//button[text()='Back']")
	public WebElement button_Back;
	
	
	
	
	
	
	
	
	
	
	

}
