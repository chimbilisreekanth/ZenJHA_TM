package com.zen.bnc.pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.zen.utils.Keywords;

public class AllPages {
	private final  WebDriver driver;
    private final ExtentTest test;
	
    //All pages
    public Keywords keywords;
    public AddOpportunity addOpportunity;
    public AO_AccountDefaults aO_AccountDefaults;
    public AO_AccountOwnership aO_accountOwnership;
    public AO_Alittlebitabout aO_Alittlebitabout;
    public AO_Alittlebitmoreabout aO_Alittlebitmoreabout;
    public AO_ApplicationDefaults aO_ApplicationDefaults;
    public AO_BSA_Product aO_BSA_Product;
    public AO_BSA aO_BSA;
    public AO_CompleteAnExistingApplication aO_CompleteAnExistingApplication;
    public AO_Depositmoney_Product aO_Depositmoney_Product;
    public AO_Depositmoney aO_Depositmoney;
    public AO_Disclosures aO_Disclosures;
    public AO_finalPage aO_finalPage;
    public AO_formsofidentification aO_formsofidentification;
    public AO_information aO_information;
    public AO_LetsGetStarted aO_LetsGetStarted;
    public AO_ProductSelection aO_ProductSelection;
    public AO_Schoolinformation aO_Schoolinformation;
    public AO_Services aO_Services;
    public EditOpportunity editOpportunity;
    public HomePage homePage ;
    public LaunchingPage launchingPage;
    public Loginpage loginpage;
    public Manage_Opportunities manage_Opportunities;
    public Menus menus;
    public OpportunityManagement opportunityManagement;
    public RolePage rolePage;
    public AO_Certificateproductdetails aO_Certificateproductdetails;
    public AO_IRA1_Createorselectretirementplan aO_IRA1_Createorselectretirementplan;
    public AO_Pod aO_Pod;
    public AO_creditcheckpopup aO_creditcheckpopup;
    public AO_AppManagement aO_AppManagement;
    public SelectLocation selectLocation;
    
    //All pages Factory
    public AllPages(WebDriver driver, ExtentTest test) {  
        super();  
        this.driver = driver;
        this.test = test;
        PageFactory.initElements(driver, this);
       
        keywords = new Keywords(driver, test);
        addOpportunity = new AddOpportunity(driver, test);
        aO_AccountDefaults = new AO_AccountDefaults(driver, test);
        aO_accountOwnership= new AO_AccountOwnership(driver, test);
        aO_Alittlebitabout= new AO_Alittlebitabout(driver, test);
        aO_Alittlebitmoreabout= new AO_Alittlebitmoreabout(driver, test);
        aO_ApplicationDefaults= new AO_ApplicationDefaults(driver, test);
        aO_BSA_Product= new AO_BSA_Product(driver, test);
        aO_BSA= new AO_BSA(driver, test);
        aO_CompleteAnExistingApplication= new AO_CompleteAnExistingApplication(driver, test);
        aO_Depositmoney_Product= new AO_Depositmoney_Product(driver, test);
        aO_Depositmoney= new AO_Depositmoney(driver, test);
        aO_Disclosures= new AO_Disclosures(driver, test);
        aO_finalPage= new AO_finalPage(driver, test);
        aO_formsofidentification= new AO_formsofidentification(driver, test);
        aO_information= new AO_information(driver, test);
        aO_LetsGetStarted= new AO_LetsGetStarted(driver, test);
        aO_ProductSelection= new AO_ProductSelection(driver, test);
        aO_Schoolinformation= new AO_Schoolinformation(driver, test);
        aO_Services= new AO_Services(driver, test);
        editOpportunity= new EditOpportunity(driver, test);
        homePage= new HomePage(driver, test);
        launchingPage= new LaunchingPage(driver, test);
        loginpage= new Loginpage(driver, test);
        manage_Opportunities= new Manage_Opportunities(driver, test);
        menus= new Menus(driver, test);
        opportunityManagement= new OpportunityManagement(driver, test);
        rolePage= new RolePage(driver, test);
        aO_Certificateproductdetails = new AO_Certificateproductdetails(driver, test);
        aO_IRA1_Createorselectretirementplan = new AO_IRA1_Createorselectretirementplan(driver, test);
        aO_Pod = new AO_Pod(driver, test);
        aO_creditcheckpopup = new  AO_creditcheckpopup(driver, test);
        aO_AppManagement = new AO_AppManagement(driver, test);
        selectLocation = new SelectLocation(driver, test);
    }
}
