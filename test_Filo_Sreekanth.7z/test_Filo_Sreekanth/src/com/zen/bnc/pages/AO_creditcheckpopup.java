package com.zen.bnc.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.zen.utils.Keywords;

public class AO_creditcheckpopup extends Keywords{
	public AO_creditcheckpopup(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//button[text()='Go to Application Management']")
	public WebElement btn_GotoApplicationManagement;
	
	@FindBy(xpath="//button[text()='Exit']")
	public WebElement btn_Exit;
	
	@FindBy(xpath="//li[@class='arrow ng-scope']")
	public List<WebElement> CategoriesList;
	
	public AO_AppManagement navigate_AppManagement(){
		if(isElementVisibile(btn_GotoApplicationManagement)){
			clickOnElement(btn_GotoApplicationManagement);
		}
	AO_AppManagement ao_AppManagement = new AO_AppManagement(driver, test);		
	PageFactory.initElements(driver, ao_AppManagement);
	return ao_AppManagement;
	}

}
