package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_AccountDefaults extends Keywords{

	public AO_AccountDefaults(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//span[text()='Yes']")
	public WebElement option_addAnotherAddress;
	
	@FindBy(xpath="//input[@name='accountTitle1']")
	public WebElement txtbx_accountTitle1;
	@FindBy(xpath="//input[@placeholder='Account Title2']")
	public WebElement txtbx_AccountTitle2;
	@FindBy(xpath="//input[@name='primary']")
	public WebElement txtbx_primary;
	@FindBy(xpath="//input[@name='addressLine2']")
	public WebElement txtbx_addressLine2;
	@FindBy(xpath="//input[@name='zipCode']")
	public WebElement txtbx_zipCode;
	@FindBy(xpath="//input[@name='city']")
	public WebElement txtbx_city;
	@FindBy(xpath="//select[@name='state']")
	public WebElement dd_state;	
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_AccountDefaults_title;	
	
	public void verifyPageload_AO_AccountDefaults() throws InterruptedException{
		verifyTitle_Content(AO_AccountDefaults_title, "Defaults");	
	}
	
	public AO_BSA_Product navigate_AO_BSA_Product(String acctdefualts) throws InterruptedException{
		Thread.sleep(2000);
		String spliter[] = acctdefualts.split(",");
		//personal
		String accountTitle1 = spliter[0];
		String AccountTitle2 = spliter[1];
		String primary = spliter[2];
		String addressLine2 = spliter[3];
		String zipCode = spliter[4];
		String city = spliter[5];
		String state = spliter[6];
		
		isElementVisibile(option_addAnotherAddress);		
		EnterDataOnTextBox(txtbx_accountTitle1, accountTitle1);		
		EnterDataOnTextBox(txtbx_AccountTitle2, AccountTitle2);		
		EnterDataOnTextBox(txtbx_primary, primary);
		
		if(isElementVisibile(txtbx_addressLine2)){
			//txtbx_addressLine2
			EnterDataOnTextBox(txtbx_addressLine2, addressLine2);	
		}
		
		EnterDataOnTextBox(txtbx_zipCode, zipCode);		
		EnterDataOnTextBox(txtbx_city, city);		
		selectDropDownValue(dd_state, state);
		// option_addAnotherAddress
		moveScrollToWebElement(button_Continue);
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_AO_BSA_Product Method Execution");
		
		AO_BSA_Product ao_BSA_Product = new AO_BSA_Product(driver, test);		
		PageFactory.initElements(driver, ao_BSA_Product);
		return ao_BSA_Product;
	}
	
//	public void verifyPageload_LetsGetStarted(){
//		verifyTitle_Content(AO_LetsGetStarted_title, "Let's get started!");
//		
//	}

}
