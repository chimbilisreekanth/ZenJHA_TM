package com.zen.bnc.pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_AccountOwnership extends Keywords{
	
	public AO_AccountOwnership(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//h2[@class='primary1Bold ng-binding']")
	public WebElement AO_AccountOwnership_title;
	
	@FindBy(xpath="//button[text()='Continue']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//button[text()='Confirm']")
	public WebElement button_Confirm;
	
	
	@FindBy(xpath="//label[@class='ng-binding ng-scope']")
	public List<WebElement> productSelection;
	
	@FindBy(xpath="//span[text()='Add applicant']")
	public WebElement button_Addapplicant;
	
	@FindBy(xpath="//span[contains(.,'Personal')]")
	public WebElement cust_Personal;
	
	@FindBy(xpath="//span[contains(.,'Business')]")
	public WebElement cust_Business;
	
	@FindBy(xpath="//input[@aria-label='Customer ID Number']")
	public WebElement textbox_custNbr;
	
	@FindBy(xpath="//button[@data-ng-click='doPartySearch()']")
	public WebElement button_seach;
	
	@FindBy(xpath="//span[contains(.,'No customer records found. Please try again')]")
	public WebElement msg_Nocustomerrecordsfound;
	
	@FindBy(xpath="//button[contains(.,'Add New Customer')]")
	public WebElement btn_AddNewCustomer;
	
	
	@FindBy(xpath="//form/div[5]/ul/li/div/div")
	public WebElement drop_PrimaryApplicant;
	
	@FindBy(xpath="//form/div[6]/ul/li/div/div")
	public WebElement drop_POBBenificiary;
	
	@FindBy(xpath="//span[@class='custfullname ng-binding ng-scope']")
	public WebElement drag_customer;
	
	@FindBy(xpath="//span[@class='ng-scope'][text()='Back']")
	public WebElement button_addcust_back;
	
	@FindBy(xpath="//span[@class='custfullname ng-binding ng-scope']")
	public WebElement drop_click;
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickAddOrEdit()']")
	public WebElement informationPage_Button_clickAddOrEdit;
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickAddOrEdit()']")
	public WebElement textbox_Busines_custNbr;
	
	public void verifyPageload_AccountOwnership() throws InterruptedException{
		//isElementVisibile(AO_AccountOwnership_title);
		verifyTitle_Content(AO_AccountOwnership_title, "Account Ownership");		
	}
	
	public void productSelection1() throws InterruptedException {
		selectOption(productSelection, "Personal Agency");	//label[@data-value='Individual']	
	}
	
	public void productSelection(String Ownership) throws InterruptedException {
		selectOption(productSelection, Ownership);	//label[@data-value='Individual']	
	}	
	
	/*public void AddapplicantA000004() throws InterruptedException{
		clickOnElement(button_Addapplicant);
		EnterDataOnTextBox(textbox_custNbr, "A000004");
		moveScrollToWebElement(button_seach);
		clickOnElement(button_seach);
	}*/
	
	public void Addapplicant(String custType, String Addapplicant) throws InterruptedException{
		Thread.sleep(2000);
		if(isElementVisibile(button_Addapplicant)){
			clickOnElement(button_Addapplicant);	
		}		
		isElementVisibile(button_seach);
		if (custType.equalsIgnoreCase("Personal")) {
			clickOnElement(cust_Personal);
		} else {
			clickOnElement(cust_Business);
		}
		moveScrollToWebElement(textbox_custNbr);
		clearData_Textfield(textbox_custNbr);
		EnterDataOnTextBox(textbox_custNbr, Addapplicant);
		moveScrollToWebElement(button_seach);
		clickOnElement(button_seach);
		if(isElementVisibile(msg_Nocustomerrecordsfound)){
			clickOnElement(btn_AddNewCustomer);
		}			
		dragandDropCustomer();
	}
	
	public void Addpod(String podType,String pod) throws InterruptedException{
		clickOnElement(button_Addapplicant);
		if(isElementVisibile(button_addcust_back)){
			clickOnElement(button_addcust_back);	
		}		
		isElementVisibile(button_seach);
		if (podType.equalsIgnoreCase("Personal")) {
			clickOnElement(cust_Personal);
		} else {
			clickOnElement(cust_Business);
		}
		moveScrollToWebElement(textbox_custNbr);
		clearData_Textfield(textbox_custNbr);
		EnterDataOnTextBox(textbox_custNbr, pod);
		moveScrollToWebElement(button_seach);
		clickOnElement(button_seach);
		if(isElementVisibile(msg_Nocustomerrecordsfound)){
			clickOnElement(btn_AddNewCustomer);
		}
		dragandDropperson();
	}
	
	/*public void AddapplicantKAA0058(){
		clickOnElement(button_Addapplicant);
		clickOnElement(button_addcust_back);		
		EnterDataOnTextBox(textbox_custNbr, "KAA0058");
		isElementVisibile(button_seach);
		clickOnElement(button_seach);
	}*/
	
	public void dragandDropCustomer() throws InterruptedException{
		isElementVisibile(button_Continue);
		moveScrollToWebElement(button_Addapplicant);
		dragAndDrop(drag_customer, drop_PrimaryApplicant);
		rightClick(drop_click);
		//drop_click.sendKeys(Keys.ESCAPE);
		//escClick();
	}
	
	public void dragandDropperson() throws InterruptedException{
		isElementVisibile(button_Continue);
		dragAndDrop(drag_customer, drop_POBBenificiary);
		rightClick(drop_click);
		Thread.sleep(2000);
	}
	
	/*public void addCust() throws InterruptedException{
		AddapplicantA000004();
		dragandDropCustomer();
		AddapplicantKAA0058();
		dragandDropperson();
	}*/
	
	public void button_Continue(){
		handle_weAreSorry();
		clickOnElement(button_Continue);
	}
	
	public AO_Alittlebitabout navigate_Alittlebitabout() throws InterruptedException{
		Thread.sleep(2000);
		handle_weAreSorry();
		moveScrollToWebElement(informationPage_Button_clickAddOrEdit);
		isElementVisibile(informationPage_Button_clickAddOrEdit);
		clickOnElement(informationPage_Button_clickAddOrEdit);
		test.log(LogStatus.INFO, "Completed navigate_Alittlebitabout Method Execution");
		
		AO_Alittlebitabout ao_Alittlebitabout = new AO_Alittlebitabout(driver, test);		
		PageFactory.initElements(driver, productSelection);
		return ao_Alittlebitabout;
	}
	
	public AO_BSA navigate_BSA() throws InterruptedException, IOException{
		Thread.sleep(2000);
		moveScrollToWebElement(button_Confirm);
		isElementVisibile(button_Confirm);
		clickOnElement(button_Confirm);
		
		AO_BSA ao_BSA = new AO_BSA(driver, test);		
		PageFactory.initElements(driver, productSelection);
		return ao_BSA;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
