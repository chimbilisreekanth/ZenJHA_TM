package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_Alittlebitmoreabout extends Keywords{

	public AO_Alittlebitmoreabout(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//input[@name='primary']")
	public WebElement txtbx_primary;
	@FindBy(xpath="//input[@name='city']")
	public WebElement txtbx_city;
	@FindBy(xpath="//select[@name='state']")
	public WebElement dd_state;
	@FindBy(xpath="//input[@name='zipCode']")
	public WebElement txtbx_zipCode;
	
	@FindBy(xpath="//input[@name='mailing']")
	public WebElement txtbx_mailing;
	@FindBy(xpath="//input[@name='mailingCity']")
	public WebElement txtbx_mailingCity;
	@FindBy(xpath="//select[@name='mailingState']")
	public WebElement dd_mailingState;
	@FindBy(xpath="//input[@name='mailingZipCode']")
	public WebElement txtbx_mailingZipCode;
	
	@FindBy(xpath="//input[@aria-label='Date of Birth (MM/DD/YYY)']")
	public WebElement DOB;
	@FindBy(xpath="//select[@aria-label='Insider Type']")
	public WebElement dd_InsiderType;
	@FindBy(xpath="//select[@name='insiderType']")
	public WebElement dd_InsiderType1;
	@FindBy(xpath="//input[@aria-label='Inquiry ID Code']")
	public WebElement txtbx_InquiryIDCode;
	@FindBy(xpath="//input[@aria-label=' Occupation']")
	public WebElement txtbx_Occupation;
	@FindBy(xpath="//input[@aria-label='Employer/School Name']")
	public WebElement txtbx_EmployerSchoolName;
	
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;
	
	@FindBy(xpath="//select[@aria-label='Employment Status']")
	public WebElement dd_EmploymentStatus;
	
	@FindBy(xpath="//input[@id='withholding2']")
	public WebElement radiobutton_subjectTo;	
	
	@FindBy(xpath="//input[@id='check1']")
	public WebElement Checkbox_Iaccept;
		
	@FindBy(xpath="//input[@aria-label='Nature of Business']")
	public WebElement NatureofBusiness;	
	
	@FindBy(xpath="//input[@aria-label='Tax Identification Number']")
	public WebElement txtbx_TaxIdentificationNumber;
	
	@FindBy(xpath="//input[@aria-label='Tax Identification Number'][@disabled='disabled']")
	public WebElement txtbx_TaxIdentificationNumberdisabled;
	
	
	
	public AO_formsofidentification navigate_formsofidentification(String BussInfo,String PrsnInfo) throws InterruptedException{
		String spliter_BussInfo[] = BussInfo.split(",");
		String ZipCode = spliter_BussInfo[0];
		String NatureBusiness = spliter_BussInfo[1];
		String insiderType = spliter_BussInfo[2];
		
		String spliter_PrsnInfo[] = PrsnInfo.split(",");
		String ocupatin = spliter_PrsnInfo[0];
		String schoolName = spliter_PrsnInfo[1];
		String steertAdd = spliter_PrsnInfo[2];
		String city = spliter_PrsnInfo[3];
		String state = spliter_PrsnInfo[4];
		String tin = spliter_PrsnInfo[5];
		
		handle_weAreSorry();		
		//selectDropDownValue(dd_EmploymentStatus, "RETIRED");
		moveScrollToWebElement(txtbx_zipCode);
		if(isElementVisibile(txtbx_zipCode)){
			EnterDataOnTextBox(txtbx_primary, steertAdd);
			EnterDataOnTextBox(txtbx_city, city);
			selectDropDownValue(dd_state, state);
			EnterDataOnTextBox(txtbx_zipCode, ZipCode);
		}
		
		if(isElementVisibile(txtbx_mailingZipCode)){
			moveScrollToWebElement(txtbx_mailingZipCode);
			EnterDataOnTextBox(txtbx_mailing, steertAdd);
			EnterDataOnTextBox(txtbx_mailingCity, city);
			selectDropDownValue(dd_mailingState, state);
			EnterDataOnTextBox(txtbx_mailingZipCode, ZipCode);
		}
		
		if (isElementVisibile(NatureofBusiness)){
			EnterDataOnTextBox(NatureofBusiness, NatureBusiness);
			selectDropDownValue(dd_InsiderType, insiderType);
		}
		if(isElementVisibile(DOB)){
			EnterDataOnTextBox(DOB, getCustomDatePast(10, "Y"));
			if(isElementVisibile(dd_InsiderType1)){
				selectDropDownValue(dd_InsiderType1, insiderType);
			}else{
			selectDropDownValue(dd_InsiderType, insiderType);
			}
			EnterDataOnTextBox(txtbx_InquiryIDCode, ZipCode);
		}		
		moveScrollToWebElement(Checkbox_Iaccept);
		if (isElementVisibile(txtbx_Occupation)){
			if(!isElementVisibile(txtbx_TaxIdentificationNumberdisabled)){
				EnterDataOnTextBox(txtbx_TaxIdentificationNumber, tin);
			}		
			EnterDataOnTextBox(txtbx_Occupation, ocupatin);
			EnterDataOnTextBox(txtbx_EmployerSchoolName, schoolName);	
		}		
		ClickOnCheckbox(radiobutton_subjectTo);
		ClickOnCheckbox(Checkbox_Iaccept);
		clickOnElement(button_Continue);
		test.log(LogStatus.INFO, "Completed navigate_formsofidentification Method Execution");
		
		AO_formsofidentification ao_formsofidentification = new AO_formsofidentification(driver, test);		
		PageFactory.initElements(driver, ao_formsofidentification);
		return ao_formsofidentification;
	}


}
