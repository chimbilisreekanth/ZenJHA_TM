package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_IRA1_Createorselectretirementplan extends Keywords{
	
	public AO_IRA1_Createorselectretirementplan(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//label[contains(.,'New Plan')]")
	public WebElement option_NewPlan;
	
	@FindBy(xpath="//select[@data-label='Plan Type']")
	public WebElement dd_PlanType;
	
	@FindBy(xpath="//input[@aria-label='Beneficiary 1 portion']")
	public WebElement txtbx_Beneficiary1portion;
	
	// Beneficiary1
	@FindBy(xpath="//select[@aria-label='Type']")
	public WebElement dd_Beneficiary1_Type;
	
	@FindBy(xpath="//input[@aria-label='Entity Name']")
	public WebElement txtbx_EntityName;
	
	@FindBy(xpath="//input[@aria-label='Beneficiary Name']")
	public WebElement txtbx_BeneficiaryName;
	
	@FindBy(xpath="//input[@aria-label='Date of Birth (MM/DD/YYYY)']")
	public WebElement txtbx_dob;
	
	@FindBy(xpath="//select[@aria-label='Gender']")
	public WebElement dd_Gender;
	
	//US Address
	@FindBy(xpath="//input[@aria-label='Street Address']")
	public WebElement txtbx_StreetAddress;
	
	@FindBy(xpath="//input[@aria-label='City']")
	public WebElement txtbx_City;
	
	@FindBy(xpath="//select[@aria-label='State']")
	public WebElement dd_State;
	
	@FindBy(xpath="//input[@aria-label='Enter Zip Code']")
	public WebElement txtbx_zipCode;
	
	@FindBy(xpath="//input[@name='taxId0']")
	public WebElement txtbx_EIN;
	
	@FindBy(xpath="//button[@data-ng-click='openAcctCtrl.clickSubmit()']")
	public WebElement button_Continue;
	
	public AO_Depositmoney_Product navigateTo_AO_Depositmoney_Product(String ira1Info) throws InterruptedException{
		String spliter[] = ira1Info.split(",");
		String PlanType = spliter[0];
		String Beneficiary1portion = spliter[1];
		String Beneficiary1_Type = spliter[2];
		String name = spliter[3];
		String dob = spliter[4];
		String Gender = spliter[5];
		String StreetAddress = spliter[6];
		String City = spliter[7];
		String State = spliter[8];
		String zipCode = spliter[9];
		String EIN = spliter[10];
		
		if(isElementVisibile(option_NewPlan)){
			selectDropDownValue(dd_PlanType, PlanType);
			EnterDataOnTextBox(txtbx_Beneficiary1portion, Beneficiary1portion);
			EnterDataOnTextBox(dd_Beneficiary1_Type, Beneficiary1_Type);
			if(Beneficiary1_Type.equalsIgnoreCase("SPOUSE")){
				EnterDataOnTextBox(txtbx_BeneficiaryName, name);
				EnterDataOnTextBox(txtbx_dob, dob);
				selectDropDownValue(dd_Gender, Gender);				
			}
			if(Beneficiary1_Type.equalsIgnoreCase("ENTITY/TRUST")){
				EnterDataOnTextBox(txtbx_EntityName, name);
			}			
			EnterDataOnTextBox(txtbx_StreetAddress, StreetAddress);
			EnterDataOnTextBox(txtbx_City, City);
			selectDropDownValue(dd_State, State);
			EnterDataOnTextBox(txtbx_zipCode, zipCode);
			moveScrollToWebElement(txtbx_EIN);
			EnterDataOnTextBox(txtbx_EIN, EIN);			
			clickOnElement(button_Continue);
			
			test.log(LogStatus.INFO, "Completed navigateTo_AO_Depositmoney_Product Method Execution");
		}
		
		AO_Depositmoney_Product aO_Depositmoney_Product = new AO_Depositmoney_Product(driver, test);		
		PageFactory.initElements(driver, aO_Depositmoney_Product);
		return aO_Depositmoney_Product;
	}

}
