package com.zen.bnc.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.zen.utils.Keywords;

public class AO_AppManagement extends Keywords{
	
	public AO_AppManagement(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}
	
	@FindBy(xpath="//button[contains(.,'Lock')]")
	public WebElement btn_Lock;
	
	@FindBy(xpath="//button[contains(.,'Process')]")
	public WebElement btn_Process;
	
	@FindBy(xpath="//button[@class='stageDetailsBtn primaryActionButton']")
	public WebElement btn_Verification_Details;	
	
	@FindBy(xpath="//span[contains(.,'External Verification')]")
	public WebElement lnk_ExternalVerification;	
	
	@FindBy(xpath="//td[contains(@class,'ng-binding ng-scope')]")
	public WebElement lnk_PrimaryUser;	
	
	@FindBy(xpath="//span[contains(.,'Credit Check')]")
	public WebElement lnk_CreditCheck;
	
	@FindBy(xpath="//span[text()='Back']")
	public WebElement lnk_Back;
	
	@FindBy(xpath="//button[contains(.,'Override Status')]")
	public WebElement btn_OverrideStatus;
	
	@FindBy(xpath="//button[contains(.,'Submit')]")
	public WebElement btn_Submit;
	
	@FindBy(xpath="//select[@id='processAction']")
	public WebElement dd_processAction;
	
	@FindBy(xpath="//textarea[@id='notes']")
	public WebElement txtbx_notes;
	
	@FindBy(xpath="//a[text()='v']")
	public WebElement lnk_close;
	
	@FindBy(xpath="//button[contains(.,'Continue')]")
	public WebElement btn_Continue;
	
	
	public AO_ApplicationDefaults navigate_ApplicationDefaults(String appmngmt) throws InterruptedException{
		String spliter[] = appmngmt.split(",");
		String processAction = spliter[0];
		String notes = spliter[1];
		
		if(isElementVisibile(btn_Lock)){
			ClickOn(btn_Lock);
		}
		isElementVisibile(btn_Process);
		moveScrollToWebElement(btn_Verification_Details);
		clickOnElement(btn_Verification_Details);
		if(isElementVisibile(lnk_ExternalVerification)){
			ClickOn(lnk_ExternalVerification);
		}
		if(isElementVisibile(lnk_PrimaryUser)){
			ClickOn(lnk_PrimaryUser);
		}
		if(isElementVisibile(lnk_CreditCheck)){
			ClickOn(lnk_CreditCheck);
		}
		if(isElementVisibile(lnk_Back)){
			moveScrollToWebElement(btn_OverrideStatus);
			ClickOn(btn_OverrideStatus);
		}
		if(isElementVisibile(btn_Submit)){
			selectDropDownValue(dd_processAction, processAction);
			EnterDataOnTextBox(txtbx_notes, notes);
		}
		clickOnElement(btn_Submit);
		
		if(isElementVisibile(lnk_PrimaryUser)){
			clickOnElement(lnk_close);
		}
		if(isElementVisibile(btn_Lock)){
			clickOnElement(btn_Lock);
		}
		if(isElementVisibile(btn_Continue)){
			clickOnElement(btn_Continue);
		}		
		AO_ApplicationDefaults ao_ApplicationDefaults = new AO_ApplicationDefaults(driver, test);		
		PageFactory.initElements(driver, ao_ApplicationDefaults);
		return ao_ApplicationDefaults;
	}
}
