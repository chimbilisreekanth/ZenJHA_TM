package com.zen.bnc.pages;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.zen.utils.Keywords;

public class AO_ProductSelection extends Keywords{
	
	public AO_ProductSelection(WebDriver driver, ExtentTest test){
		super(driver, test);
		PageFactory.initElements((driver), this);
	}	
	
	@FindBy(xpath="//h2[contains(@class,'primary1Bold ng-binding')]")
	public WebElement AO_ProductSelection_title;
	
	@FindBy(xpath="//button[contains(.,'Cancel')]")
	public WebElement button_Cancel;
	
	@FindBy(xpath="//button[contains(.,'Continue')]")
	public WebElement button_Continue;
	
	@FindBy(xpath="//button[contains(.,'Back')]")
	public WebElement button_Back;
	
	@FindBy(xpath="//p[text()='Personal']")
	public WebElement tab_Personal;
	
	@FindBy(xpath="//a[@data-ng-click='generateRegExp(menu)']")
	public WebElement tab_Business;
	
	@FindBy(xpath="//a[@ng-click='navAction(menu)']")
	public List<WebElement> ProductmenuList;
	
	@FindBy(xpath="//a[contains(.,' Add to cart ')]")
	public List<WebElement> button_Addtocart;
	
	
	@FindBy(xpath="//div[@class='productName ng-binding']")
	public List<WebElement> ProductList;
	
	
	@FindBy(xpath="//button[@class='primaryActionButton']")
	public WebElement button_AddtoCart;
	
	
	public void verifyPageload_ProductSelection() throws InterruptedException{
		verifyTitle_Content(AO_ProductSelection_title, "Product Selection");
	}
	
	public void productSelection_P(String Productmenu, String Product) throws InterruptedException{
		clickOnElement(tab_Personal);
		isElementsVisibile(button_Addtocart);
		selectOption(ProductmenuList, Productmenu);
		selectOption(ProductList,Product);
		Thread.sleep(2000);
		moveScrollToWebElement(button_AddtoCart);
		clickOnElement(button_AddtoCart);	
	}
	
	public void productSelection_B(String Productmenu, String Product) throws InterruptedException{
		clickOnElement(tab_Business);
		isElementsVisibile(button_Addtocart);
		selectOption(ProductmenuList, Productmenu);
		selectOption(ProductList,Product);
		Thread.sleep(2000);
		moveScrollToWebElement(button_AddtoCart);
		clickOnElement(button_AddtoCart);		
	}
	
	public void productSelection(String ProductType, String Productmenu, String Product) throws InterruptedException{
				
		if (ProductType.equalsIgnoreCase("Personal")) {
			clickOnElement(tab_Personal);
		} else {
			clickOnElement(tab_Business);
		}
		isElementsVisibile(button_Addtocart);
		selectOption(ProductmenuList, Productmenu);
		selectOption(ProductList,Product);
		isElementVisibile(button_AddtoCart);
		moveScrollToWebElement(button_AddtoCart);
		clickOnElement(button_AddtoCart);
		Thread.sleep(2000);
		test.log(LogStatus.INFO, "Selected ProductType:--"+ProductType+"Selected Productmenu:"+Productmenu+"Selected Product:"+Product);
	}
	public void productSelection2(String ProductType, String Productmenu, String Product) throws InterruptedException{
		
		/*if (ProductType.equalsIgnoreCase("Personal")) {
			clickOnElement(tab_Personal);
		} else {
			clickOnElement(tab_Business);
		}*/
		isElementsVisibile(button_Addtocart);
		selectOption(ProductmenuList, Productmenu);
		selectOption(ProductList,Product);
		Thread.sleep(2000);
		moveScrollToWebElement(button_AddtoCart);
		clickOnElement(button_AddtoCart);
		Thread.sleep(2000);
	}
	public AO_AccountOwnership goto_AccountOwnership() throws InterruptedException{
		moveScrollToWebElement(button_Continue);
		clickOnElement(button_Continue);
		
		AO_AccountOwnership ao_AccountOwnership = new AO_AccountOwnership(driver, test);		
		PageFactory.initElements(driver, ao_AccountOwnership);
		test.log(LogStatus.INFO, "Completed goto_AccountOwnership Method Execution");
		return ao_AccountOwnership;
	}
	
	
	
	

}
